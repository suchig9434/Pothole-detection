"""
backend/data_ingest.py
----------------------
Generates 150 mock potholes around Raipur and uploads them to Firestore.
Timestamps are spread randomly across the last 30 days so time filtering works.

Usage:
    python -m backend.data_ingest
"""

import random
import uuid
from datetime import datetime, timedelta

from backend.firebase_client import initialize_firebase

# ── Raipur city centre ──────────────────────────────────────────────────────
CENTER_LAT = 21.2514
CENTER_LON = 81.6296

SEVERITIES = ["low", "medium", "high"]
SEVERITY_WEIGHTS = [0.4, 0.35, 0.25]   # more low than high — realistic spread


def _random_timestamp(days_back: int = 30) -> str:
    delta = timedelta(
        days=random.uniform(0, days_back),
        hours=random.uniform(0, 24),
        minutes=random.uniform(0, 60),
    )
    return (datetime.utcnow() - delta).isoformat()


def generate_mock_potholes(n: int = 150) -> list[dict]:
    potholes = []
    for _ in range(n):
        lat = CENTER_LAT + random.uniform(-0.05, 0.05)
        lon = CENTER_LON + random.uniform(-0.05, 0.05)
        severity = random.choices(SEVERITIES, weights=SEVERITY_WEIGHTS, k=1)[0]

        pothole = {
            "pothole_id":       str(uuid.uuid4()),
            "latitude":         round(lat, 6),
            "longitude":        round(lon, 6),
            "severity":         severity,
            "source":           "mock",
            "timestamp":        _random_timestamp(30),
            "complaint_status": random.choice(["pending", "acknowledged", "resolved"]),
        }
        potholes.append(pothole)
    return potholes


def upload_mock_data(n: int = 150) -> None:
    db = initialize_firebase()

    # Clear existing mock potholes first (idempotent re-run)
    print("Clearing existing mock potholes…")
    existing = db.collection("potholes").where("source", "==", "mock").stream()
    for doc in existing:
        doc.reference.delete()

    potholes = generate_mock_potholes(n)
    print(f"Uploading {len(potholes)} mock potholes…")

    for p in potholes:
        db.collection("potholes").document(p["pothole_id"]).set(p)

    print(f"Done — {len(potholes)} potholes uploaded to Firestore.")


if __name__ == "__main__":
    upload_mock_data()
