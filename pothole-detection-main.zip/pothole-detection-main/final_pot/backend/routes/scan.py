"""
backend/routes/scan.py
-----------------------
POST /scan/start   — kick off background road scan
GET  /scan/status  — poll scan progress
POST /scan/stop    — stop current scan
POST /scan/detect-street-view — detect potholes from a Street View image
"""

import base64

from flask import Blueprint, request, jsonify
from backend.services.scan_service import (
    start_scan,
    stop_scan,
    get_status,
    detect_street_view,
    DEFAULT_STREET_VIEW_FOV,
)

scan_routes = Blueprint("scan_routes", __name__)


@scan_routes.post("/scan/start")
def route_start():
    body  = request.get_json(silent=True) or {}
    north = body.get("north")
    south = body.get("south")
    east  = body.get("east")
    west  = body.get("west")

    if any(v is None for v in [north, south, east, west]):
        return jsonify({"error": "north/south/east/west required"}), 400

    ok, msg, session_id = start_scan(float(north), float(south), float(east), float(west))
    if ok:
        return jsonify({"status": "started", "session_id": session_id}), 200
    return jsonify({"error": msg}), 409


@scan_routes.get("/scan/status")
def route_status():
    return jsonify(get_status()), 200


@scan_routes.post("/scan/stop")
def route_stop():
    stop_scan()
    return jsonify({"status": "stopped"}), 200


@scan_routes.post("/scan/detect-street-view")
def route_detect_street_view():
    body = request.get_json(silent=True) or {}

    lat = body.get("lat")
    lng = body.get("lng")

    if lat is None or lng is None:
        return jsonify({"error": "lat and lng are required"}), 400

    try:
        lat = float(lat)
        lng = float(lng)
        heading = float(body.get("heading", 0))
        fov = int(body.get("fov", DEFAULT_STREET_VIEW_FOV))
        pitch = int(body.get("pitch", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "lat/lng/heading must be numeric and fov/pitch must be integers"}), 400

    ok, message, payload = detect_street_view(lat, lng, heading=heading, fov=fov, pitch=pitch)
    if not ok:
        status = 503 if message and "GMAPS_KEY" in message else 502
        return jsonify({"error": message or "Street View detection failed"}), status

    image_bytes = payload.pop("image_bytes", None)
    if image_bytes:
        payload["image_base64"] = base64.b64encode(image_bytes).decode("ascii")

    return jsonify(payload), 200
