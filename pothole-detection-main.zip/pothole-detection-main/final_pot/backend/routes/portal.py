"""
backend/routes/portal.py
------------------------
Portal endpoints for citizen complaints and authority fixed-pothole reports.
"""

from __future__ import annotations

from flask import Blueprint, jsonify, request

from backend.services.portal_service import create_complaint_submission, create_fixed_submission


portal_routes = Blueprint("portal_routes", __name__)


def _parse_float(value, field_name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} must be a number") from None


@portal_routes.post("/portal/complaints")
def route_submit_complaint():
    image = request.files.get("image")
    latitude = request.form.get("latitude")
    longitude = request.form.get("longitude")
    severity = request.form.get("severity", "medium")
    note = request.form.get("note", "")

    if image is None:
        return jsonify({"error": "image is required"}), 400

    try:
        lat = _parse_float(latitude, "latitude")
        lng = _parse_float(longitude, "longitude")
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    try:
        payload = create_complaint_submission(
            latitude=lat,
            longitude=lng,
            severity=severity,
            note=note,
            image_file=image,
        )
        return jsonify(payload), 201
    except Exception as exc:
        return jsonify({"error": f"Complaint submission failed: {exc}"}), 500


@portal_routes.post("/portal/fixed-reports")
def route_submit_fixed_report():
    image = request.files.get("image")
    latitude = request.form.get("latitude")
    longitude = request.form.get("longitude")
    pothole_id = (request.form.get("pothole_id") or "").strip()
    note = request.form.get("note", "")

    if image is None:
        return jsonify({"error": "image is required"}), 400

    try:
        lat = _parse_float(latitude, "latitude")
        lng = _parse_float(longitude, "longitude")
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    try:
        payload = create_fixed_submission(
            latitude=lat,
            longitude=lng,
            pothole_id=pothole_id,
            note=note,
            image_file=image,
        )
        return jsonify(payload), 201
    except Exception as exc:
        return jsonify({"error": f"Fixed pothole submission failed: {exc}"}), 500