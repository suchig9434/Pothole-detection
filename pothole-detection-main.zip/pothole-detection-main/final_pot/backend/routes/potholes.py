"""
backend/routes/potholes.py
---------------------------
REST endpoints for pothole data.

GET /potholes          → all potholes
GET /potholes?since=7d → potholes from last 7 days (24h | 7d | 30d)
"""

import heapq

from flask import Blueprint, jsonify, request
from backend.services.pothole_service import get_potholes

pothole_routes = Blueprint("potholes", __name__)


@pothole_routes.route("/potholes", methods=["GET"])
def fetch_potholes():
    since = request.args.get("since", None)   # e.g. "24h", "7d", "30d"
    data  = get_potholes(since=since)
    return jsonify(data)


@pothole_routes.route("/potholes/priority-queue", methods=["GET"])
def fetch_priority_queue():
    try:
        limit = int(request.args.get("limit", "8"))
    except (TypeError, ValueError):
        limit = 8

    limit = max(1, min(limit, 50))

    north = request.args.get("north")
    south = request.args.get("south")
    east = request.args.get("east")
    west = request.args.get("west")

    has_bbox = all(value is not None for value in (north, south, east, west))

    north_f = south_f = east_f = west_f = None
    if has_bbox:
        try:
            north_f = float(north)
            south_f = float(south)
            east_f = float(east)
            west_f = float(west)
        except (TypeError, ValueError):
            return jsonify({"error": "north/south/east/west must be numeric"}), 400

        if south_f > north_f:
            south_f, north_f = north_f, south_f

    # Lazy import so the main app can still boot even if clustering dependencies are missing.
    from backend.complaint_scheduler import (
        fetch_unreported_potholes,
        cluster_potholes,
        build_priority_queue,
    )

    potholes = fetch_unreported_potholes()
    clusters = cluster_potholes(potholes)
    queue = build_priority_queue(clusters)

    def cluster_in_bounds(cluster: dict) -> bool:
        if not has_bbox:
            return True

        lat = cluster.get("cluster_latitude")
        lon = cluster.get("cluster_longitude")
        try:
            lat_f = float(lat)
            lon_f = float(lon)
        except (TypeError, ValueError):
            return False

        if not (south_f <= lat_f <= north_f):
            return False

        # Handle anti-meridian gracefully if it is ever needed.
        if west_f <= east_f:
            return west_f <= lon_f <= east_f
        return lon_f >= west_f or lon_f <= east_f

    items = []
    while queue and len(items) < limit:
        _, _, _, _, cluster = heapq.heappop(queue)
        if not cluster_in_bounds(cluster):
            continue

        cluster_age = cluster.get("cluster_age")
        pothole_ids = []
        for pothole in cluster.get("potholes", []):
            pothole_id = pothole.get("_doc_id") or pothole.get("pothole_id") or pothole.get("id")
            if pothole_id is None:
                continue
            text = str(pothole_id).strip()
            if text:
                pothole_ids.append(text)

        pothole_ids = list(dict.fromkeys(pothole_ids))

        items.append(
            {
                "cluster_id": cluster.get("cluster_id"),
                "latitude": cluster.get("cluster_latitude"),
                "longitude": cluster.get("cluster_longitude"),
                "severity": cluster.get("severity_level", "low"),
                "severity_score": cluster.get("cluster_severity_score", 1.0),
                "cluster_count": cluster.get("cluster_count", 1),
                "oldest_timestamp": cluster_age.isoformat() if cluster_age else None,
                "pothole_ids": pothole_ids,
            }
        )

    return jsonify({
        "items": items,
        "total_clusters": len(clusters),
        "filtered": has_bbox,
    })
