"""
backend/routes/maps.py
----------------------
Google Maps powered location search endpoint.
"""

from flask import Blueprint, jsonify, request

from backend.services.google_maps_service import GoogleMapsSearchError, search_place


maps_routes = Blueprint("maps_routes", __name__)


@maps_routes.get("/maps/search")
def route_maps_search():
    query = request.args.get("q", "")
    if not query.strip():
        return jsonify({"error": "q query parameter is required"}), 400

    try:
        result = search_place(query)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except GoogleMapsSearchError as exc:
        return jsonify({"error": str(exc)}), exc.status_code

    return jsonify(result), 200