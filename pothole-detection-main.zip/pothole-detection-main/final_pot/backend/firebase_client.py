import json
import os

import firebase_admin
from firebase_admin import credentials, firestore, storage


def initialize_firebase():
    """Singleton Firebase initializer — safe to call multiple times."""
    if not firebase_admin._apps:
        cred_path = os.path.join(os.path.dirname(__file__), "firebase_key.json")
        cred = credentials.Certificate(cred_path)

        # Auto-derive storage bucket from project_id if env var not set
        with open(cred_path) as f:
            project_id = json.load(f).get("project_id", "")
        bucket = os.environ.get(
            "FIREBASE_STORAGE_BUCKET",
            f"{project_id}.firebasestorage.app",
        )

        firebase_admin.initialize_app(cred, {"storageBucket": bucket})

    return firestore.client()


def get_storage_bucket():
    """Return the default Firebase Storage bucket (admin SDK)."""
    return storage.bucket()
