"""
backend/complaint_runner.py
---------------------------
Runs automated complaint scheduling daily at 09:00.
"""

import time

import schedule

from backend.complaint_scheduler import send_daily_complaints


SCHEDULE_TIME = "09:00"


def _run_job() -> None:
    print("Starting scheduled complaint run")
    send_daily_complaints()


def main() -> None:
    schedule.every().day.at(SCHEDULE_TIME).do(_run_job)
    print(f"Complaint runner started. Scheduled daily at {SCHEDULE_TIME}")

    while True:
        schedule.run_pending()
        time.sleep(20)


if __name__ == "__main__":
    main()
