"""
backend/reverification_runner.py
--------------------------------
Hourly scheduler for automatic email reverification.
"""

import time

import schedule

from backend.email_verification import run_reverification


def _run_job() -> None:
    print("Starting scheduled email reverification run")
    run_reverification()


def main() -> None:
    schedule.every(1).hours.do(_run_job)
    print("Reverification runner started. Scheduled every 1 hour")

    while True:
        schedule.run_pending()
        time.sleep(20)


if __name__ == "__main__":
    main()
