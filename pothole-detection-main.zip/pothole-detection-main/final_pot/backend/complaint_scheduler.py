"""
backend/complaint_scheduler.py
------------------------------
Automatic complaint scheduler:
1. Fetch pending potholes from Firestore
2. Cluster by geographic proximity (DBSCAN + haversine)
3. Prioritize clusters by severity, age, and count
4. Send complaint emails for top clusters
5. Mark reported potholes as acknowledged
"""

from __future__ import annotations

import heapq
from datetime import datetime, timezone
from typing import Any

import numpy as np
from google.api_core.exceptions import GoogleAPICallError, RetryError
from sklearn.cluster import DBSCAN

from backend.email_complaint import send_pothole_complaint
from backend.firebase_client import initialize_firebase


EARTH_RADIUS_M = 6_371_000.0
CLUSTER_DISTANCE_M = 50.0
TOP_CLUSTER_LIMIT = 8

SEVERITY_SCORE_MAP = {
	"low": 1.0,
	"medium": 2.0,
	"moderate": 2.0,
	"high": 3.0,
	"severe": 3.0,
	"dangerous": 3.0,
}


def _parse_timestamp(value: Any) -> datetime:
	if isinstance(value, datetime):
		return value if value.tzinfo else value.replace(tzinfo=timezone.utc)

	if isinstance(value, str):
		normalized = value.replace("Z", "+00:00")
		try:
			parsed = datetime.fromisoformat(normalized)
			return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
		except ValueError:
			pass

	return datetime.now(timezone.utc)


def _severity_score(pothole: dict[str, Any]) -> float:
	raw_score = pothole.get("severity_score")
	if raw_score is not None:
		try:
			return float(raw_score)
		except (TypeError, ValueError):
			pass

	severity = str(pothole.get("severity", "")).strip().lower()
	return SEVERITY_SCORE_MAP.get(severity, 1.0)


def _severity_level_from_score(score: float) -> str:
	if score >= 3.0:
		return "high"
	if score >= 2.0:
		return "medium"
	return "low"


def fetch_unreported_potholes() -> list[dict[str, Any]]:
	"""Fetch potholes where complaint_status == pending."""
	db = initialize_firebase()

	try:
		docs = db.collection("potholes").where("complaint_status", "==", "pending").stream()
	except (GoogleAPICallError, RetryError, Exception) as exc:
		print(f"Firestore fetch failed: {exc}")
		return []

	potholes: list[dict[str, Any]] = []
	skipped = 0

	for doc in docs:
		data = doc.to_dict() or {}

		lat = data.get("latitude")
		lon = data.get("longitude")

		try:
			lat_f = float(lat)
			lon_f = float(lon)
		except (TypeError, ValueError):
			skipped += 1
			continue

		data["_doc_id"] = doc.id
		data["_doc_ref"] = doc.reference
		data["latitude"] = lat_f
		data["longitude"] = lon_f
		data["_timestamp"] = _parse_timestamp(data.get("timestamp"))
		data["_severity_score"] = _severity_score(data)
		potholes.append(data)

	print(f"Fetched {len(potholes)} pending potholes from Firestore")
	if skipped:
		print(f"Skipped {skipped} potholes due to invalid coordinates")

	return potholes


def cluster_potholes(potholes: list[dict[str, Any]]) -> list[dict[str, Any]]:
	"""
	Cluster potholes using DBSCAN + haversine distance.
	Two potholes are in one cluster if distance <= 50m.
	"""
	if not potholes:
		return []

	coords = np.array(
		[[p["latitude"], p["longitude"]] for p in potholes],
		dtype=np.float64,
	)

	coords_rad = np.radians(coords)
	eps = CLUSTER_DISTANCE_M / EARTH_RADIUS_M

	model = DBSCAN(
		eps=eps,
		min_samples=1,
		metric="haversine",
		algorithm="ball_tree",
	)
	labels = model.fit_predict(coords_rad)

	grouped: dict[int, list[dict[str, Any]]] = {}
	for label, pothole in zip(labels, potholes):
		grouped.setdefault(int(label), []).append(pothole)

	clusters: list[dict[str, Any]] = []
	for cluster_id, members in grouped.items():
		cluster_latitude = float(np.mean([p["latitude"] for p in members]))
		cluster_longitude = float(np.mean([p["longitude"] for p in members]))
		cluster_severity_score = float(max(p["_severity_score"] for p in members))
		cluster_age = min(p["_timestamp"] for p in members)
		cluster_count = len(members)

		cluster = {
			"cluster_id": cluster_id,
			"cluster_latitude": cluster_latitude,
			"cluster_longitude": cluster_longitude,
			"cluster_severity_score": cluster_severity_score,
			"cluster_age": cluster_age,
			"cluster_count": cluster_count,
			"severity_level": _severity_level_from_score(cluster_severity_score),
			"potholes": members,
		}
		clusters.append(cluster)

		print(f"Cluster created with {cluster_count} potholes")

	print(f"Total clusters formed: {len(clusters)}")
	return clusters


def build_priority_queue(clusters: list[dict[str, Any]]) -> list[tuple[Any, ...]]:
	"""
	Priority rules (highest first):
	1) cluster_severity_score
	2) cluster_age (older first)
	3) cluster_count
	"""
	queue: list[tuple[Any, ...]] = []

	for i, cluster in enumerate(clusters):
		severity_key = -float(cluster["cluster_severity_score"])
		age_key = cluster["cluster_age"].timestamp()
		count_key = -int(cluster["cluster_count"])

		heapq.heappush(queue, (severity_key, age_key, count_key, i, cluster))

	return queue


def _acknowledge_cluster(db, cluster: dict[str, Any]) -> None:
	batch = db.batch()
	reported_at = datetime.utcnow()

	for pothole in cluster["potholes"]:
		doc_ref = pothole.get("_doc_ref")
		if doc_ref is None:
			doc_id = pothole.get("_doc_id")
			if doc_id:
				doc_ref = db.collection("potholes").document(doc_id)
		if doc_ref is None:
			continue

		batch.update(
			doc_ref,
			{
				"complaint_status": "acknowledged",
				"reported_at": reported_at,
			},
		)

	batch.commit()


def send_daily_complaints() -> list[dict[str, Any]]:
	"""Main scheduler flow for complaint generation and dispatch."""
	potholes = fetch_unreported_potholes()
	if not potholes:
		print("No pending potholes found")
		return []

	clusters = cluster_potholes(potholes)
	if not clusters:
		print("No clusters generated")
		return []

	queue = build_priority_queue(clusters)

	selected_clusters: list[dict[str, Any]] = []
	while queue and len(selected_clusters) < TOP_CLUSTER_LIMIT:
		_, _, _, _, cluster = heapq.heappop(queue)
		selected_clusters.append(cluster)

	print(f"Selected top {len(selected_clusters)} clusters for complaints")

	db = initialize_firebase()

	for cluster in selected_clusters:
		lat = cluster["cluster_latitude"]
		lon = cluster["cluster_longitude"]

		print(f"Sending complaint for cluster at {lat:.6f}, {lon:.6f}")
		try:
			send_pothole_complaint(cluster)
			print("Complaint sent successfully")
		except Exception as exc:
			print(f"Complaint send failed: {exc}")
			continue

		try:
			_acknowledge_cluster(db, cluster)
			print("Firestore updated")
		except (GoogleAPICallError, RetryError, Exception) as exc:
			print(f"Firestore update failed: {exc}")

	return selected_clusters


if __name__ == "__main__":
	send_daily_complaints()
