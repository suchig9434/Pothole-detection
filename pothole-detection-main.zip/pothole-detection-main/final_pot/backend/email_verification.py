"""
backend/email_verification.py
-----------------------------
Automatic email reverification pipeline:
1. Read repair-confirmation replies from Gmail via IMAP
2. Download attached repair images
3. Run detect_potholes(image_path)
4. Update Firestore verification_status
5. Mark emails processed
"""

from __future__ import annotations

import email
import imaplib
import importlib
import os
import re
import sys
import uuid
from datetime import datetime, timezone
from email.header import decode_header
from pathlib import Path
from typing import Any

from firebase_admin import firestore

from backend.firebase_client import initialize_firebase


DEFAULT_IMAP_HOST = "imap.gmail.com"
DEFAULT_IMAP_PORT = 993
DEFAULT_IMAP_FOLDER = "INBOX"
DEFAULT_REPAIR_SUBJECT_PREFIX = "REPAIRED:"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DOWNLOAD_DIR = PROJECT_ROOT / "data" / "verification_images"

_DETECT_FN = None


def _decode_mime_header(raw_value: str | None) -> str:
	if not raw_value:
		return ""

	decoded_parts = decode_header(raw_value)
	chunks = []
	for value, encoding in decoded_parts:
		if isinstance(value, bytes):
			enc = encoding or "utf-8"
			chunks.append(value.decode(enc, errors="replace"))
		else:
			chunks.append(value)
	return "".join(chunks)


def _resolve_detector_function():
	global _DETECT_FN
	if _DETECT_FN is not None:
		return _DETECT_FN

	# Use the original pothole detector pipeline for reverification.
	candidate_dir = PROJECT_ROOT.parent / "pothole_detector" / "pothole_detector2" / "Pothole_YOLOv8"
	if candidate_dir.exists() and str(candidate_dir) not in sys.path:
		sys.path.insert(0, str(candidate_dir))

	try:
		cwd = os.getcwd()
		os.chdir(str(candidate_dir))
		sys.modules.pop("pipeline", None)
		module = importlib.import_module("pipeline")
		detect_fn = getattr(module, "detect_potholes", None)
		if callable(detect_fn):
			_DETECT_FN = detect_fn
			os.chdir(cwd)
			return _DETECT_FN
		os.chdir(cwd)
	except Exception as exc:
		try:
			os.chdir(cwd)
		except Exception:
			pass
		raise RuntimeError(f"Unable to import detect_potholes from pipeline: {exc}") from exc

	raise RuntimeError("detect_potholes(image_path) function is unavailable")


def connect_to_email():
	"""Connect to Gmail IMAP inbox and return authenticated mailbox client."""
	email_address = (os.environ.get("EMAIL_ADDRESS") or "").strip()
	email_password = (os.environ.get("EMAIL_PASSWORD") or "").strip()

	if not email_address or not email_password:
		raise RuntimeError("EMAIL_ADDRESS and EMAIL_PASSWORD must be configured")

	imap_host = (os.environ.get("EMAIL_IMAP_HOST") or DEFAULT_IMAP_HOST).strip()
	imap_port_raw = (os.environ.get("EMAIL_IMAP_PORT") or str(DEFAULT_IMAP_PORT)).strip()

	try:
		imap_port = int(imap_port_raw)
	except ValueError as exc:
		raise RuntimeError(f"Invalid EMAIL_IMAP_PORT: {imap_port_raw}") from exc

	client = imaplib.IMAP4_SSL(imap_host, imap_port)
	client.login(email_address, email_password)
	return client


def fetch_repair_emails(mail_client) -> list[tuple[bytes, email.message.Message]]:
	"""
	Fetch unread emails that contain subject prefix REPAIRED:.
	Returns list of tuples (mail_id, parsed_message).
	"""
	folder = (os.environ.get("EMAIL_IMAP_FOLDER") or DEFAULT_IMAP_FOLDER).strip()
	subject_prefix = (os.environ.get("REPAIR_EMAIL_SUBJECT_PREFIX") or DEFAULT_REPAIR_SUBJECT_PREFIX).strip()

	status, _ = mail_client.select(folder)
	if status != "OK":
		raise RuntimeError(f"Unable to open mailbox folder: {folder}")

	search_status, data = mail_client.search(None, "UNSEEN", "SUBJECT", f'"{subject_prefix}"')
	if search_status != "OK":
		# Fallback search without UNSEEN constraint.
		search_status, data = mail_client.search(None, "SUBJECT", f'"{subject_prefix}"')

	if search_status != "OK" or not data or not data[0]:
		return []

	emails_found: list[tuple[bytes, email.message.Message]] = []
	for mail_id in data[0].split():
		fetch_status, payload = mail_client.fetch(mail_id, "(RFC822)")
		if fetch_status != "OK" or not payload:
			continue

		raw_bytes = None
		for row in payload:
			if isinstance(row, tuple) and len(row) >= 2:
				raw_bytes = row[1]
				break

		if not raw_bytes:
			continue

		msg = email.message_from_bytes(raw_bytes)
		emails_found.append((mail_id, msg))

	return emails_found


def _extract_pothole_id_from_subject(subject: str) -> str | None:
	pattern = re.compile(r"REPAIRED:\s*([A-Za-z0-9_\-]+)", re.IGNORECASE)
	match = pattern.search(subject or "")
	if not match:
		return None
	return match.group(1).strip()


def download_image_attachment(msg: email.message.Message, pothole_id: str) -> str | None:
	"""Download first image attachment and return saved local path."""
	download_dir = os.environ.get("REVERIFICATION_DOWNLOAD_DIR")
	output_dir = Path(download_dir) if download_dir else DEFAULT_DOWNLOAD_DIR
	output_dir.mkdir(parents=True, exist_ok=True)

	timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

	for part in msg.walk():
		if part.is_multipart():
			continue

		content_disposition = (part.get("Content-Disposition") or "").lower()
		content_type = (part.get_content_type() or "").lower()
		filename_raw = part.get_filename()

		is_image = content_type.startswith("image/")
		is_attachment = "attachment" in content_disposition or bool(filename_raw)
		if not (is_image and is_attachment):
			continue

		payload = part.get_payload(decode=True)
		if not payload:
			continue

		filename_decoded = _decode_mime_header(filename_raw) if filename_raw else ""
		suffix = Path(filename_decoded).suffix.lower() if filename_decoded else ""
		if suffix not in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
			subtype = content_type.split("/")[-1] if "/" in content_type else "jpeg"
			suffix = f".{subtype if subtype else 'jpeg'}"

		safe_pothole_id = re.sub(r"[^A-Za-z0-9_\-]", "_", pothole_id)
		output_name = f"{safe_pothole_id}_{timestamp}_{uuid.uuid4().hex[:8]}{suffix}"
		output_path = output_dir / output_name

		with open(output_path, "wb") as file_obj:
			file_obj.write(payload)

		return str(output_path)

	return None


def _extract_pothole_count(detection_result: Any) -> int:
	if isinstance(detection_result, bool):
		return 1 if detection_result else 0

	if isinstance(detection_result, (int, float)):
		return max(0, int(detection_result))

	if isinstance(detection_result, dict):
		if "count" in detection_result:
			try:
				return max(0, int(detection_result["count"]))
			except (TypeError, ValueError):
				pass

		if isinstance(detection_result.get("detections"), list):
			return len(detection_result["detections"])

		if "has_pothole" in detection_result:
			return 1 if bool(detection_result["has_pothole"]) else 0

	if isinstance(detection_result, (list, tuple, set)):
		return len(detection_result)

	return 0


def verify_repair(image_path: str) -> dict[str, Any]:
	"""Run pothole detector and determine whether repair is confirmed."""
	detect_potholes = _resolve_detector_function()
	raw_result = detect_potholes(image_path)
	pothole_count = _extract_pothole_count(raw_result)

	return {
		"is_repaired": pothole_count == 0,
		"pothole_count": pothole_count,
		"raw_result": raw_result,
	}


def update_firestore_status(pothole_id: str, verification_status: str, saved_image_path: str | None) -> int:
	"""
	Update Firestore verification_status for a cluster/document.
	Returns number of updated records.
	"""
	db = initialize_firebase()
	updated_count = 0

	updates = {
		"verification_status": verification_status,
		"verification_checked_at": firestore.SERVER_TIMESTAMP,
	}
	if verification_status == "repaired" and saved_image_path:
		updates["repair_image"] = saved_image_path
		updates["complaint_status"] = "resolved"
		updates["resolved_at"] = firestore.SERVER_TIMESTAMP

	# Primary match: cluster_id field.
	try:
		docs = list(db.collection("potholes").where("cluster_id", "==", pothole_id).stream())
	except Exception:
		docs = []

	if docs:
		for doc in docs:
			doc.reference.update(updates)
			updated_count += 1
		return updated_count

	# Fallback match: direct document id.
	try:
		doc_ref = db.collection("potholes").document(pothole_id)
		snapshot = doc_ref.get()
		if snapshot.exists:
			doc_ref.update(updates)
			updated_count += 1
	except Exception:
		pass

	return updated_count


def _mark_email_processed(mail_client, mail_id: bytes) -> None:
	# Mark as read to avoid repeat processing on next run.
	try:
		mail_client.store(mail_id, "+FLAGS", "\\Seen")
	except Exception:
		pass


def run_reverification() -> None:
	mail_client = None
	try:
		mail_client = connect_to_email()
		repair_mails = fetch_repair_emails(mail_client)
		if not repair_mails:
			print("No repair emails found")
			return

		for mail_id, msg in repair_mails:
			subject = _decode_mime_header(msg.get("Subject"))
			pothole_id = _extract_pothole_id_from_subject(subject)

			if not pothole_id:
				print("Skipping email: missing REPAIRED cluster id in subject")
				_mark_email_processed(mail_client, mail_id)
				continue

			print(f"Checking email for cluster {pothole_id}")

			try:
				image_path = download_image_attachment(msg, pothole_id)
			except Exception as exc:
				print(f"Attachment download failed: {exc}")
				_mark_email_processed(mail_client, mail_id)
				continue

			if not image_path:
				print("No image attachment found")
				_mark_email_processed(mail_client, mail_id)
				continue

			print("Image downloaded")

			try:
				verification = verify_repair(image_path)
			except Exception as exc:
				print(f"Verification error: {exc}")
				_mark_email_processed(mail_client, mail_id)
				continue

			if verification["is_repaired"]:
				print("Pothole repaired confirmed")
				updated = update_firestore_status(pothole_id, "repaired", image_path)
			else:
				print("Pothole still present")
				updated = update_firestore_status(pothole_id, "failed", image_path)

			print(f"Firestore records updated: {updated}")
			_mark_email_processed(mail_client, mail_id)

	except Exception as exc:
		print(f"Reverification run failed: {exc}")
	finally:
		if mail_client is not None:
			try:
				mail_client.close()
			except Exception:
				pass
			try:
				mail_client.logout()
			except Exception:
				pass


if __name__ == "__main__":
	run_reverification()
