"""
backend/services/scan_service.py
---------------------------------
Background road-scan service:
  1. Extract road network in bbox via OSMnx
  2. Sample GPS points every ~25 m along every road edge
    3. Fetch a Google Street View Static image at each point (4 headings)
  4. Run YOLOv8 pothole detection on the image
  5. Upload confirmed-pothole images to Firebase Storage
  6. Save pothole record (lat, lng, severity, image_url) to Firestore
"""

import os
import uuid
import copy
import base64
import math
import threading
import requests
import cv2
import numpy as np
from datetime import timedelta
from shapely.geometry import box as shapely_box, LineString
from firebase_admin import firestore, storage as fb_storage
from ultralytics import YOLO

from backend.firebase_client import initialize_firebase

# ─── Shared scan state (thread-safe) ─────────────────────────────────────────
_state = {
    "running": False,
    "done": 0,
    "total": 0,       # -1 while road network is loading
    "current_lat": None,
    "current_lng": None,
    "found": 0,
    "error": None,
    "session_id": None,
    "findings": [],
}
_lock = threading.Lock()

# ─── Lazy-loaded YOLO model ───────────────────────────────────────────────────
_model = None
_road_segmenter = None
_road_transform = None


def _get_env_float(name, default):
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _get_env_int(name, default):
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


ROAD_HEADING_OFFSETS = (0.0, 180.0)
DEFAULT_STREET_VIEW_FOV = _get_env_int("STREET_VIEW_FOV", 60)
POTHOLE_CONFIDENCE_THRESHOLD = _get_env_float("POTHOLE_CONFIDENCE_THRESHOLD", 0.45)
ENABLE_ROAD_MASK_FILTER = (os.environ.get("ENABLE_ROAD_MASK_FILTER") or "1").strip().lower() in {
    "1", "true", "yes", "on"
}


def _get_model():
    global _model
    if _model is None:
        default_path = os.path.normpath(os.path.join(
            os.path.dirname(__file__),
            "..", "..", "..",
            "pothole_detector", "pothole_detector2",
            "Pothole_YOLOv8", "models", "best.pt"
        ))
        configured_path = (os.environ.get("YOLO_MODEL_PATH") or "").strip().strip("\"").strip("'")
        model_path = configured_path or default_path

        # Resolve relative model paths from project root when provided via env.
        if not os.path.isabs(model_path):
            project_root = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", ".."))
            model_path = os.path.normpath(os.path.join(project_root, model_path))

        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"YOLO model not found at '{model_path}'. Set YOLO_MODEL_PATH to a valid .pt file."
            )

        _model = YOLO(model_path)
    return _model


def _get_road_segmenter():
    global _road_segmenter, _road_transform
    if _road_segmenter is None or _road_transform is None:
        try:
            from torchvision import models, transforms
            from torchvision.models.segmentation import DeepLabV3_MobileNet_V3_Large_Weights
        except Exception as exc:
            raise RuntimeError(
                "Road segmentation dependencies missing. Install torch and torchvision."
            ) from exc

        weights = DeepLabV3_MobileNet_V3_Large_Weights.DEFAULT
        _road_segmenter = models.segmentation.deeplabv3_mobilenet_v3_large(weights=weights)
        _road_segmenter.eval()

        _road_transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((640, 640)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

    return _road_segmenter, _road_transform


# ─── Public API ───────────────────────────────────────────────────────────────

def get_status():
    with _lock:
        return copy.deepcopy(_state)


def stop_scan():
    with _lock:
        _state["running"] = False


def start_scan(north, south, east, west):
    gmaps_key = os.environ.get("GMAPS_KEY", "")
    if not gmaps_key:
        return False, "GMAPS_KEY not set in environment (.env file)", None

    with _lock:
        if _state["running"]:
            return False, "A scan is already running", None

        session_id = uuid.uuid4().hex
        _state.update({
            "running": True, "done": 0, "total": -1,
            "current_lat": None, "current_lng": None,
            "found": 0, "error": None,
            "session_id": session_id,
            "findings": [],
        })

    t = threading.Thread(
        target=_scan_worker,
        args=(north, south, east, west, gmaps_key),
        daemon=True,
    )
    t.start()
    return True, "Scan started", session_id


def detect_street_view(lat, lng, heading=0, fov=DEFAULT_STREET_VIEW_FOV, pitch=0):
    try:
        gmaps_key = os.environ.get("GMAPS_KEY", "")
        if not gmaps_key:
            return False, "GMAPS_KEY not set in environment (.env file)", None

        model = _get_model()
        image_bytes = _fetch_street_view(lat, lng, heading, gmaps_key, fov=fov, pitch=pitch)
        if image_bytes is None:
            return False, "Failed to fetch Street View image", None

        found, best_detection, annotated_bytes = _detect_pothole(image_bytes, model)
        payload_bytes = annotated_bytes if found else image_bytes

        payload = {
            "lat": lat,
            "lng": lng,
            "heading": heading,
            "fov": fov,
            "pitch": pitch,
            "found": found,
            "detection": best_detection,
            "image_bytes": payload_bytes,
            "image_content_type": "image/jpeg",
        }

        return True, None, payload
    except Exception as exc:
        return False, f"Detection failed: {exc}", None


# ─── Background worker ────────────────────────────────────────────────────────

def _scan_worker(north, south, east, west, gmaps_key):
    try:
        import osmnx as ox

        db    = initialize_firebase()
        model = _get_model()

        # Build road graph from bounding box polygon
        polygon = shapely_box(west, south, east, north)
        G = ox.graph_from_polygon(polygon, network_type="drive")

        points = _sample_road_points(G)

        with _lock:
            _state["total"] = len(points)
            session_id = _state.get("session_id")

        for i, (lat, lng, heading) in enumerate(points):
            with _lock:
                if not _state["running"]:
                    break
                _state["done"] = i + 1
                _state["current_lat"] = lat
                _state["current_lng"] = lng

            img_bytes = _fetch_street_view(lat, lng, heading, gmaps_key)
            if img_bytes is None:
                continue

            # Persist the fetched frame first so inference input is traceable in Storage.
            frame_path = _build_scan_frame_path(lat, lng, heading, session_id=session_id)
            frame_upload_meta = _upload_image_to_path(img_bytes, frame_path)

            found, best_detection, annotated_bytes = _detect_pothole(img_bytes, model)
            if not found:
                if frame_upload_meta:
                    _delete_storage_object(frame_upload_meta["path"])
                continue

            upload_meta = None

            # Reuse the same stored frame path for detected potholes by replacing with annotated output.
            if frame_upload_meta:
                upload_meta = _upload_image_to_path(annotated_bytes, frame_upload_meta["path"])

            # Fallback path in case frame upload/update failed for this point.
            if not upload_meta:
                upload_meta = _upload_image(annotated_bytes, lat, lng, heading)

            # Remove temporary frame if final image moved to a different storage object.
            if (
                frame_upload_meta
                and upload_meta
                and frame_upload_meta.get("path") != upload_meta.get("path")
            ):
                _delete_storage_object(frame_upload_meta["path"])

            image_url = upload_meta["url"] if upload_meta else None
            image_storage_path = upload_meta["path"] if upload_meta else None
            finding = _save_pothole(
                db,
                lat,
                lng,
                best_detection["confidence"],
                best_detection["severity"],
                heading,
                image_url,
                image_storage_path=image_storage_path,
                session_id=session_id,
            )

            if not image_url:
                finding["image_base64"] = base64.b64encode(annotated_bytes).decode("ascii")
                finding["image_content_type"] = "image/jpeg"

            with _lock:
                _state["found"] += 1
                _state["findings"].append(finding)

    except Exception as exc:
        with _lock:
            _state["error"] = str(exc)
    finally:
        with _lock:
            _state["running"] = False
            if _state["total"] == -1:
                _state["total"] = 0


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _sample_road_points(G, spacing_m=25):
    """Return list of (lat, lng, heading) sampled every spacing_m metres."""
    points = []
    for u, v, data in G.edges(data=True):
        geom = data.get("geometry") or LineString([
            (G.nodes[u]["x"], G.nodes[u]["y"]),
            (G.nodes[v]["x"], G.nodes[v]["y"]),
        ])
        length = data.get("length") or 1.0
        n = max(1, int(length / spacing_m))
        for i in range(n):
            pt = geom.interpolate(i / n, normalized=True)
            base_heading = _estimate_road_heading(geom, i, n)
            for offset in ROAD_HEADING_OFFSETS:
                points.append((pt.y, pt.x, _normalize_heading(base_heading + offset)))
    return points


def _normalize_heading(heading):
    return float((heading % 360.0 + 360.0) % 360.0)


def _bearing_degrees(lat1, lng1, lat2, lng2):
    lat1_r = math.radians(lat1)
    lat2_r = math.radians(lat2)
    d_lng_r = math.radians(lng2 - lng1)

    x = math.sin(d_lng_r) * math.cos(lat2_r)
    y = (
        math.cos(lat1_r) * math.sin(lat2_r)
        - math.sin(lat1_r) * math.cos(lat2_r) * math.cos(d_lng_r)
    )

    if abs(x) < 1e-12 and abs(y) < 1e-12:
        return 0.0

    return _normalize_heading(math.degrees(math.atan2(x, y)))


def _estimate_road_heading(geom, index, total):
    if total <= 1:
        t1, t2 = 0.0, 1.0
    else:
        t = index / total
        delta = 1.0 / total
        t1 = max(0.0, t - delta)
        t2 = min(1.0, t + delta)
        if t2 <= t1:
            t1 = max(0.0, t - 0.01)
            t2 = min(1.0, t + 0.01)
        if t2 <= t1:
            return 0.0

    p1 = geom.interpolate(t1, normalized=True)
    p2 = geom.interpolate(t2, normalized=True)

    if abs(p1.x - p2.x) < 1e-9 and abs(p1.y - p2.y) < 1e-9:
        return 0.0

    return _bearing_degrees(p1.y, p1.x, p2.y, p2.x)


def _fetch_street_view(lat, lng, heading, api_key, fov=DEFAULT_STREET_VIEW_FOV, pitch=0):
    url = (
        "https://maps.googleapis.com/maps/api/streetview"
        f"?size=640x480&location={lat},{lng}"
        f"&heading={heading}&fov={fov}&pitch={pitch}&source=outdoor&key={api_key}"
    )
    try:
        r = requests.get(url, timeout=10)
        if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image"):
            return r.content
    except Exception:
        pass
    return None


def _detect_pothole(image_bytes, model):
    arr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return False, None, image_bytes

    detections, annotated = _run_detection_pipeline(img, model)
    if not detections:
        return False, None, image_bytes

    best = _pick_primary_detection(detections)

    ok, encoded = cv2.imencode(".jpg", annotated, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
    annotated_bytes = encoded.tobytes() if ok else image_bytes
    return True, best, annotated_bytes


def _run_detection_pipeline(image, model):
    height, width = image.shape[:2]

    road_mask = None
    if ENABLE_ROAD_MASK_FILTER:
        road_mask = _get_road_mask(image)
        area_reference = max(int(np.sum(road_mask)), 1)
    else:
        # Fallback mode when road-mask filtering is intentionally disabled.
        area_reference = max(height * width, 1)

    results = model(image, verbose=False)
    annotated = image.copy()
    detections = []

    for result in results:
        boxes = result.boxes
        if boxes is None or len(boxes) == 0:
            continue

        xyxy = boxes.xyxy.cpu().numpy()
        confs = boxes.conf.cpu().numpy() if boxes.conf is not None else np.zeros(len(xyxy))

        for idx, box in enumerate(xyxy):
            x1, y1, x2, y2 = map(int, box)

            x1 = max(0, min(width - 1, x1))
            y1 = max(0, min(height - 1, y1))
            x2 = max(0, min(width - 1, x2))
            y2 = max(0, min(height - 1, y2))

            if x2 <= x1 or y2 <= y1:
                continue

            conf = float(confs[idx]) if idx < len(confs) else 0.0
            if conf < POTHOLE_CONFIDENCE_THRESHOLD:
                continue

            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2

            if road_mask is not None and not road_mask[cy, cx]:
                continue

            pothole_area = max((x2 - x1) * (y2 - y1), 1)
            severity_score = pothole_area / area_reference
            severity_label, severity_value, color = _classify_severity(severity_score)

            detections.append({
                "severity": severity_value,
                "severity_label": severity_label,
                "confidence": round(conf, 3),
                "severity_score": round(float(severity_score), 6),
                "box": [x1, y1, x2, y2],
            })

            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            cv2.putText(
                annotated,
                f"{severity_label} {conf:.2f}",
                (x1, max(20, y1 - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                color,
                2,
                cv2.LINE_AA,
            )

    return detections, annotated


def _classify_severity(severity_score):
    if severity_score < 0.005:
        return "Small", "low", (0, 255, 0)
    if severity_score < 0.02:
        return "Medium", "medium", (0, 165, 255)
    return "Dangerous", "high", (0, 0, 255)


def _pick_primary_detection(detections):
    severity_rank = {"low": 1, "medium": 2, "high": 3}
    return max(
        detections,
        key=lambda d: (
            severity_rank.get(d["severity"], 0),
            d.get("confidence", 0.0),
            d.get("severity_score", 0.0),
        ),
    )


def _get_road_mask(image):
    import torch

    road_model, transform = _get_road_segmenter()

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    input_tensor = transform(image_rgb).unsqueeze(0)

    with torch.no_grad():
        output = road_model(input_tensor)["out"][0]

    prediction = output.argmax(0).cpu().numpy()
    road_mask = (prediction == 0).astype(np.uint8)

    road_mask = cv2.resize(
        road_mask,
        (image.shape[1], image.shape[0]),
        interpolation=cv2.INTER_NEAREST,
    )

    return road_mask


def _upload_image(image_bytes, lat, lng, heading):
    name = f"sv_scans/{uuid.uuid4().hex}_{lat:.5f}_{lng:.5f}_h{heading}.jpg"
    return _upload_image_to_path(image_bytes, name)


def _build_scan_frame_path(lat, lng, heading, session_id=None):
    session_segment = session_id or "adhoc"
    return f"sv_scan_frames/{session_segment}/{uuid.uuid4().hex}_{lat:.5f}_{lng:.5f}_h{heading}.jpg"


def _upload_image_to_path(image_bytes, object_path):
    try:
        bucket = fb_storage.bucket()
        blob = bucket.blob(object_path)
        blob.upload_from_string(image_bytes, content_type="image/jpeg")

        try:
            blob.make_public()
            url = blob.public_url
        except Exception:
            # Fallback for buckets using uniform access where ACL-based public URLs are disabled.
            url = blob.generate_signed_url(
                version="v4",
                method="GET",
                expiration=timedelta(days=30),
            )

        return {"url": url, "path": object_path}
    except Exception:
        return None


def _delete_storage_object(object_path):
    if not object_path:
        return False

    try:
        bucket = fb_storage.bucket()
        blob = bucket.blob(object_path)
        blob.delete()
        return True
    except Exception:
        return False


def _save_pothole(
    db,
    lat,
    lng,
    conf,
    severity,
    heading,
    image_url,
    image_storage_path=None,
    session_id=None,
):
    pipeline_name = "yolov8+road_segmentation" if ENABLE_ROAD_MASK_FILTER else "yolov8_no_road_mask_temp"
    doc_ref = db.collection("potholes").document()
    pothole_id = doc_ref.id

    doc = {
        "pothole_id":       pothole_id,
        "latitude":         lat,
        "longitude":        lng,
        "severity":         severity,
        "confidence":       round(conf, 3),
        "source":           "street_view",
        "heading":          heading,
        "pipeline":         pipeline_name,
        "complaint_status": "pending",
        "timestamp":        firestore.SERVER_TIMESTAMP,
    }
    if session_id:
        doc["scan_session_id"] = session_id
    if image_url:
        doc["image_url"] = image_url
    if image_storage_path:
        doc["image_storage_path"] = image_storage_path
    doc_ref.set(doc)

    return {
        "pothole_id": pothole_id,
        "latitude": lat,
        "longitude": lng,
        "severity": severity,
        "confidence": round(conf, 3),
        "source": "street_view",
        "heading": heading,
        "pipeline": pipeline_name,
        "scan_session_id": session_id,
        "image_url": image_url,
        "image_storage_path": image_storage_path,
    }
