"""
backend/services/google_maps_service.py
--------------------------------------
Google Maps helpers used by the frontend search experience.

The search flow resolves a user query to a map location, checks whether
Google Street View imagery exists nearby, and returns a bounded scan box that
is safe to hand to the road-scan pipeline.
"""

from __future__ import annotations

import math
import os
import re

import requests


GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
STREET_VIEW_METADATA_URL = "https://maps.googleapis.com/maps/api/streetview/metadata"
COORDINATE_RE = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$")


class GoogleMapsSearchError(RuntimeError):
    def __init__(self, message: str, status_code: int = 502):
        super().__init__(message)
        self.status_code = status_code


def search_place(query: str) -> dict:
    query = (query or "").strip()
    if not query:
        raise ValueError("Search query is required")

    api_key = os.environ.get("GMAPS_KEY", "").strip()
    if not api_key:
        raise GoogleMapsSearchError(
            "GMAPS_KEY not set in environment (.env file)",
            status_code=503,
        )

    coordinate_match = COORDINATE_RE.match(query)
    if coordinate_match:
        lat = float(coordinate_match.group(1))
        lng = float(coordinate_match.group(2))
        formatted_address = f"{lat:.5f}, {lng:.5f}"
        address_components = []
        map_bounds = _bbox_from_radius(lat, lng, radius_m=500)
    else:
        geocode_result = _geocode_query(query, api_key)
        geometry = geocode_result.get("geometry") or {}
        location = geometry.get("location") or {}

        lat = float(location["lat"])
        lng = float(location["lng"])
        formatted_address = geocode_result.get("formatted_address") or query
        address_components = geocode_result.get("address_components") or []
        raw_map_bounds = _viewport_to_bbox(geometry.get("viewport"), lat, lng)
        map_bounds = _clamp_bbox(raw_map_bounds, lat, lng, max_radius_m=900)

    street_view = _street_view_metadata(lat, lng, api_key)
    street_view_location = street_view.get("location") or {"lat": lat, "lng": lng}
    scan_bbox = _bbox_from_radius(
        float(street_view_location["lat"]),
        float(street_view_location["lng"]),
        radius_m=250,
    )

    district = _pick_address_component(
        address_components,
        ["administrative_area_level_2", "locality", "administrative_area_level_1"],
    ) or "Raipur"
    locality = _pick_address_component(
        address_components,
        ["sublocality_level_1", "sublocality", "neighborhood", "route", "locality"],
    ) or formatted_address

    return {
        "query": query,
        "formatted_address": formatted_address,
        "district": district,
        "locality": locality,
        "location": {"lat": lat, "lng": lng},
        "map_bounds": map_bounds,
        "scan_bbox": scan_bbox,
        "scan_radius_m": 250,
        "street_view": street_view,
    }


def _geocode_query(query: str, api_key: str) -> dict:
    try:
        response = requests.get(
            GEOCODE_URL,
            params={"address": query, "key": api_key},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
    except requests.RequestException as exc:
        raise GoogleMapsSearchError("Google Maps geocoding request failed") from exc

    status = payload.get("status")
    results = payload.get("results") or []
    if status == "ZERO_RESULTS" or not results:
        raise GoogleMapsSearchError(f'No location found for "{query}"', status_code=404)
    if status != "OK":
        raise GoogleMapsSearchError(payload.get("error_message") or f"Geocoding failed: {status}")

    return results[0]


def _street_view_metadata(lat: float, lng: float, api_key: str) -> dict:
    try:
        response = requests.get(
            STREET_VIEW_METADATA_URL,
            params={
                "location": f"{lat},{lng}",
                "source": "outdoor",
                "key": api_key,
            },
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
    except requests.RequestException as exc:
        raise GoogleMapsSearchError("Google Street View metadata request failed") from exc

    status = payload.get("status", "UNKNOWN")
    metadata_location = payload.get("location") or {"lat": lat, "lng": lng}

    return {
        "available": status == "OK",
        "status": status,
        "date": payload.get("date"),
        "pano_id": payload.get("pano_id"),
        "copyright": payload.get("copyright"),
        "location": {
            "lat": float(metadata_location.get("lat", lat)),
            "lng": float(metadata_location.get("lng", lng)),
        },
    }


def _viewport_to_bbox(viewport: dict | None, lat: float, lng: float) -> dict:
    northeast = (viewport or {}).get("northeast") or {}
    southwest = (viewport or {}).get("southwest") or {}
    if {"lat", "lng"}.issubset(northeast) and {"lat", "lng"}.issubset(southwest):
        return {
            "north": float(northeast["lat"]),
            "south": float(southwest["lat"]),
            "east": float(northeast["lng"]),
            "west": float(southwest["lng"]),
        }
    return _bbox_from_radius(lat, lng, radius_m=500)


def _bbox_from_radius(lat: float, lng: float, radius_m: float) -> dict:
    lat_delta = radius_m / 111_320
    lng_scale = max(math.cos(math.radians(lat)), 0.1)
    lng_delta = radius_m / (111_320 * lng_scale)
    return {
        "north": lat + lat_delta,
        "south": lat - lat_delta,
        "east": lng + lng_delta,
        "west": lng - lng_delta,
    }


def _clamp_bbox(bbox: dict, lat: float, lng: float, max_radius_m: float) -> dict:
    limit = _bbox_from_radius(lat, lng, radius_m=max_radius_m)
    return {
        "north": min(float(bbox["north"]), limit["north"]),
        "south": max(float(bbox["south"]), limit["south"]),
        "east": min(float(bbox["east"]), limit["east"]),
        "west": max(float(bbox["west"]), limit["west"]),
    }


def _pick_address_component(address_components: list[dict], priority: list[str]) -> str | None:
    for wanted_type in priority:
        for component in address_components:
            if wanted_type in (component.get("types") or []):
                return component.get("long_name")
    return None