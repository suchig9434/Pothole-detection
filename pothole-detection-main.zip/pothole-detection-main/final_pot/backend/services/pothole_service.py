"""
backend/services/pothole_service.py
------------------------------------
Reads potholes from Firestore with an optional time window filter.
"""

from datetime import datetime, timedelta
from backend.firebase_client import initialize_firebase


_SINCE_MAP = {
    "24h":  timedelta(hours=24),
    "7d":   timedelta(days=7),
    "30d":  timedelta(days=30),
}


def get_potholes(since: str | None = None) -> list[dict]:
    db   = initialize_firebase()
    ref  = db.collection("potholes")

    docs = ref.stream()
    data = []

    cutoff = None
    if since and since in _SINCE_MAP:
        cutoff = datetime.utcnow() - _SINCE_MAP[since]

    for doc in docs:
        d = doc.to_dict()

        if cutoff:
            ts_str = d.get("timestamp", "")
            try:
                ts = datetime.fromisoformat(ts_str)
                if ts < cutoff:
                    continue
            except (ValueError, TypeError):
                pass  # include if unparseable

        data.append(d)

    return data
