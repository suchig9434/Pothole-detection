"""
backend/services/portal_service.py
----------------------------------
Portal workflow service:
1. Citizen complaint upload (image + lat/lng)
2. Authority fixed-pothole proof upload (image + lat/lng)
3. Optional external verification model hook for fixed-pothole proof
"""

from __future__ import annotations

import os
import uuid
from datetime import timedelta
from typing import Any

import requests
from firebase_admin import firestore, storage as fb_storage

from backend.firebase_client import initialize_firebase


def _normalize_severity(raw: Any) -> str:
    value = str(raw or "").strip().lower()
    if value in {"high", "severe", "dangerous"}:
        return "high"
    if value in {"medium", "moderate"}:
        return "medium"
    return "low"


def _upload_image_bytes(image_bytes: bytes, object_path: str, content_type: str) -> dict[str, str] | None:
    try:
        bucket = fb_storage.bucket()
        blob = bucket.blob(object_path)
        blob.upload_from_string(image_bytes, content_type=content_type)

        try:
            blob.make_public()
            url = blob.public_url
        except Exception:
            url = blob.generate_signed_url(
                version="v4",
                method="GET",
                expiration=timedelta(days=30),
            )

        return {"url": url, "path": object_path}
    except Exception:
        return None


def _safe_read_image(file_storage) -> tuple[bytes, str]:
    image_bytes = file_storage.read() if file_storage else b""
    if not image_bytes:
        raise ValueError("image is required")

    content_type = (getattr(file_storage, "mimetype", "") or "image/jpeg").strip() or "image/jpeg"
    return image_bytes, content_type


def _verify_fixed_pothole(image_bytes: bytes, content_type: str) -> dict[str, Any]:
    """
    Verification hook for future fixed-road model integration.
    - If FIXED_POTHOLE_MODEL_ENDPOINT is configured, request that model API.
    - Otherwise return a pending-model status so UI can inform the authority.
    """
    endpoint = (os.environ.get("FIXED_POTHOLE_MODEL_ENDPOINT") or "").strip()
    if not endpoint:
        return {
            "status": "model_not_configured",
            "verified": False,
            "confidence": None,
            "message": "Verification model endpoint is not configured yet",
        }

    try:
        response = requests.post(
            endpoint,
            files={"image": ("fixed_pothole.jpg", image_bytes, content_type)},
            timeout=30,
        )

        payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
        if not response.ok:
            return {
                "status": "verification_error",
                "verified": False,
                "confidence": None,
                "message": payload.get("error") or f"Verifier HTTP {response.status_code}",
            }

        status = payload.get("status")
        if not status:
            status = "verified" if payload.get("verified") else "rejected"

        return {
            "status": status,
            "verified": bool(payload.get("verified", False)),
            "confidence": payload.get("confidence"),
            "message": payload.get("message") or "Verification completed",
            "raw": payload,
        }
    except Exception as exc:
        return {
            "status": "verification_error",
            "verified": False,
            "confidence": None,
            "message": f"Verifier call failed: {exc}",
        }


def create_complaint_submission(
    *,
    latitude: float,
    longitude: float,
    severity: str,
    note: str,
    image_file,
) -> dict[str, Any]:
    db = initialize_firebase()

    image_bytes, content_type = _safe_read_image(image_file)
    object_path = f"portal_complaints/{uuid.uuid4().hex}.jpg"
    upload_meta = _upload_image_bytes(image_bytes, object_path, content_type)
    if not upload_meta:
        raise RuntimeError("Image upload failed. Check Firebase Storage bucket configuration.")

    doc = {
        "latitude": latitude,
        "longitude": longitude,
        "severity": _normalize_severity(severity),
        "source": "citizen_portal",
        "complaint_status": "pending",
        "timestamp": firestore.SERVER_TIMESTAMP,
        "title": note or "Citizen complaint upload",
    }
    doc["image_url"] = upload_meta["url"]
    doc["image_storage_path"] = upload_meta["path"]

    doc_ref = db.collection("potholes").document()
    doc_ref.set(doc)

    return {
        "complaint_id": doc_ref.id,
        "latitude": latitude,
        "longitude": longitude,
        "severity": doc["severity"],
        "image_url": upload_meta["url"],
        "queued_for_complaint": True,
    }


def create_fixed_submission(
    *,
    latitude: float,
    longitude: float,
    pothole_id: str,
    note: str,
    image_file,
) -> dict[str, Any]:
    db = initialize_firebase()

    image_bytes, content_type = _safe_read_image(image_file)
    object_path = f"portal_fixed_reports/{uuid.uuid4().hex}.jpg"
    upload_meta = _upload_image_bytes(image_bytes, object_path, content_type)
    if not upload_meta:
        raise RuntimeError("Image upload failed. Check Firebase Storage bucket configuration.")

    verification = _verify_fixed_pothole(image_bytes, content_type)

    report_ref = db.collection("fixed_pothole_reports").document()
    report_doc = {
        "report_id": report_ref.id,
        "latitude": latitude,
        "longitude": longitude,
        "pothole_id": pothole_id or None,
        "note": note or "",
        "submitted_at": firestore.SERVER_TIMESTAMP,
        "verification": {
            "status": verification.get("status"),
            "verified": bool(verification.get("verified", False)),
            "confidence": verification.get("confidence"),
            "message": verification.get("message"),
        },
    }

    report_doc["image_url"] = upload_meta["url"]
    report_doc["image_storage_path"] = upload_meta["path"]

    report_ref.set(report_doc)

    pothole_updated = False
    if pothole_id and verification.get("verified"):
        try:
            db.collection("potholes").document(pothole_id).update(
                {
                    "complaint_status": "resolved",
                    "resolved_at": firestore.SERVER_TIMESTAMP,
                    "resolution_report_id": report_ref.id,
                }
            )
            pothole_updated = True
        except Exception:
            pothole_updated = False

    return {
        "report_id": report_ref.id,
        "verification": report_doc["verification"],
        "pothole_id": pothole_id or None,
        "pothole_status_updated": pothole_updated,
        "image_url": upload_meta["url"],
    }