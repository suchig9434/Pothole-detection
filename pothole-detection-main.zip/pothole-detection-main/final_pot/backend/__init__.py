"""backend package bootstrap."""

import os

from dotenv import load_dotenv


_DOTENV_PATH = os.path.join(os.path.dirname(__file__), "..", ".env")
load_dotenv(_DOTENV_PATH)
