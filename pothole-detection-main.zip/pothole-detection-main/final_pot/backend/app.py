"""
backend/app.py
--------------
Flask application entry point.

Run from the final_pot/ root:
    python -m backend.app
"""

import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from flask import Flask
from flask_cors import CORS
from backend.routes.maps import maps_routes
from backend.routes.potholes import pothole_routes
from backend.routes.portal import portal_routes
from backend.routes.scan import scan_routes

app = Flask(__name__)
CORS(app)

app.register_blueprint(maps_routes)
app.register_blueprint(pothole_routes)
app.register_blueprint(portal_routes)
app.register_blueprint(scan_routes)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
