import { MapContainer, TileLayer, Circle, CircleMarker, Popup, Rectangle, useMap, useMapEvents } from "react-leaflet"
import { useEffect, useState, useRef, useMemo } from "react"
import L from "leaflet"
import "leaflet.heat"
import StreetViewModal from "./StreetViewModal"

const API_BASE = "http://127.0.0.1:5000"

// ─── Severity helpers ────────────────────────────────────────────────────────

function normaliseSeverity(raw) {
  const s = (raw || "").toLowerCase()
  if (s === "high" || s === "dangerous" || s === "severe") return "high"
  if (s === "medium" || s === "moderate") return "medium"
  return "low"
}

function formatCoord(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n.toFixed(5) : "—"
}

const SEVERITY_COLOR  = { high: "#ef4444", medium: "#f97316", low: "#22c55e" }
const SEVERITY_WEIGHT = { high: 1.0, medium: 0.65, low: 0.3 }

// ─── Zoom thresholds ─────────────────────────────────────────────────────────
const ZOOM_DISTRICT      = 12
const ZOOM_NEIGHBOURHOOD = 15
const REALTIME_POLL_MS = 8000
const RESOLVED_FADE_MS = 6000
const FADE_FRAME_MS = 120


function isResolvedPothole(pothole) {
  const complaintStatus = String(pothole?.complaint_status || "").toLowerCase()
  const verificationStatus = String(pothole?.verification_status || "").toLowerCase()
  return complaintStatus === "resolved" || verificationStatus === "repaired"
}


function getPotholeRenderKey(pothole) {
  if (pothole?.pothole_id) return `id:${String(pothole.pothole_id)}`
  if (pothole?.cluster_id) return `cluster:${String(pothole.cluster_id)}`

  const lat = Number(pothole?.latitude)
  const lng = Number(pothole?.longitude)
  const ts = pothole?.timestamp ? String(pothole.timestamp) : ""
  const latKey = Number.isFinite(lat) ? lat.toFixed(6) : "na"
  const lngKey = Number.isFinite(lng) ? lng.toFixed(6) : "na"
  return `geo:${latKey}:${lngKey}:${ts}`
}

function bboxToRectangleBounds(bbox) {
  return [
    [bbox.south, bbox.west],
    [bbox.north, bbox.east],
  ]
}

// ─── HeatLayer ───────────────────────────────────────────────────────────────
function HeatLayer({ potholes, zoom }) {
  const map     = useMap()
  const heatRef = useRef(null)

  useEffect(() => {
    if (!potholes.length) return

    if (heatRef.current) {
      map.removeLayer(heatRef.current)
      heatRef.current = null
    }

    if (zoom > ZOOM_NEIGHBOURHOOD) return

    const isDistrict = zoom < ZOOM_DISTRICT

    const points = potholes
      .map(p => {
        const lat = Number(p.latitude)
        const lng = Number(p.longitude)
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null

        const alphaRaw = Number(p._render_opacity)
        const alpha = Number.isFinite(alphaRaw) ? Math.max(0, Math.min(1, alphaRaw)) : 1
        if (alpha <= 0) return null

        const baseWeight = SEVERITY_WEIGHT[normaliseSeverity(p.severity)]
        return [lat, lng, baseWeight * alpha]
      })
      .filter(Boolean)

    if (!points.length) return

    const heat = L.heatLayer(points, {
      radius:  isDistrict ? 60 : 35,
      blur:    isDistrict ? 50 : 28,
      maxZoom: 18,
      max: 1.0,
      gradient: {
        0.0:  "#22c55e",
        0.4:  "#facc15",
        0.65: "#f97316",
        1.0:  "#ef4444"
      }
    })

    heat.addTo(map)
    heatRef.current = heat

    return () => {
      if (heatRef.current) {
        map.removeLayer(heatRef.current)
        heatRef.current = null
      }
    }
  }, [potholes, zoom, map])

  return null
}

// ─── Discrete markers ────────────────────────────────────────────────────────
function DiscreteMarkers({ potholes, zoom, onOpenStreetView }) {
  if (zoom <= ZOOM_NEIGHBOURHOOD) return null

  return potholes.map((p, i) => {
    const lat = Number(p.latitude)
    const lng = Number(p.longitude)
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null

    const alphaRaw = Number(p._render_opacity)
    const alpha = Number.isFinite(alphaRaw) ? Math.max(0, Math.min(1, alphaRaw)) : 1
    if (alpha <= 0) return null

    const sev = normaliseSeverity(p.severity)
    const color = SEVERITY_COLOR[sev]
    const hasImage = Boolean(p.image_url)
    const renderKey = p._render_key || getPotholeRenderKey(p)
    const isResolved = isResolvedPothole(p)

    return (
      <CircleMarker
        key={renderKey || i}
        center={[lat, lng]}
        radius={7}
        pathOptions={{
          color,
          fillColor: color,
          fillOpacity: 0.85 * alpha,
          opacity: 0.9 * alpha,
          weight: 1.5,
        }}
      >
        <Popup className="pothole-popup">
          <div className="popup-inner">
            <span className="popup-sev" style={{ background: color }}>
              {sev.toUpperCase()}
            </span>
            <p><strong>Source:</strong> {p.source || "—"}</p>
            <p className="popup-coords"><strong>Lat:</strong> {formatCoord(lat)}</p>
            <p className="popup-coords"><strong>Lng:</strong> {formatCoord(lng)}</p>
            {p.title && <p><strong>Note:</strong> {p.title}</p>}
            {p.timestamp && (
              <p className="popup-time">
                {new Date(p.timestamp).toLocaleDateString()}
              </p>
            )}
            {isResolved && (
              <p className="popup-time">Resolved - fading out</p>
            )}

            {hasImage && (
              <div className="popup-image-wrap">
                <img
                  className="popup-image"
                  src={p.image_url}
                  alt="Detected pothole"
                  loading="lazy"
                />
                <a
                  className="popup-image-link"
                  href={p.image_url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open image ↗
                </a>
              </div>
            )}

            <button
              className="sv-btn"
              onClick={() => onOpenStreetView(lat, lng, Number(p.heading))}
            >
              📷 Street View
            </button>
          </div>
        </Popup>
      </CircleMarker>
    )
  })
}

// ─── Zoom tracker ─────────────────────────────────────────────────────────────
function ZoomTracker({ onZoomChange }) {
  useMapEvents({ zoomend: e => onZoomChange(e.target.getZoom()) })
  return null
}

function BoundsTracker({ onBoundsChange }) {
  const map = useMap()

  useEffect(() => {
    if (!onBoundsChange) return

    const emitBounds = () => {
      const bounds = map.getBounds()
      onBoundsChange({
        north: bounds.getNorth(),
        south: bounds.getSouth(),
        east: bounds.getEast(),
        west: bounds.getWest(),
      })
    }

    emitBounds()
    map.on("moveend", emitBounds)
    map.on("zoomend", emitBounds)

    return () => {
      map.off("moveend", emitBounds)
      map.off("zoomend", emitBounds)
    }
  }, [map, onBoundsChange])

  return null
}
// ─── Bbox draw tool ──────────────────────────────────────────────────
function DrawBbox({ enabled, onBboxSelect }) {
  const map = useMap()

  useEffect(() => {
    if (!enabled) return

    let startLatLng = null
    let rect = null

    map.dragging.disable()
    map.getContainer().style.cursor = "crosshair"

    const onMouseDown = (e) => {
      startLatLng = e.latlng
      if (rect) { map.removeLayer(rect); rect = null }
    }

    const onMouseMove = (e) => {
      if (!startLatLng) return
      if (rect) map.removeLayer(rect)
      rect = L.rectangle([startLatLng, e.latlng], {
        color: "#22c55e", weight: 2, dashArray: "8 4",
        fillOpacity: 0.08, interactive: false,
      }).addTo(map)
    }

    const onMouseUp = (e) => {
      if (!startLatLng) return
      const bounds = L.latLngBounds(startLatLng, e.latlng)
      if (rect) { map.removeLayer(rect); rect = null }
      onBboxSelect({
        north: bounds.getNorth(),
        south: bounds.getSouth(),
        east:  bounds.getEast(),
        west:  bounds.getWest(),
      })
      startLatLng = null
    }

    map.on("mousedown", onMouseDown)
    map.on("mousemove", onMouseMove)
    map.on("mouseup",   onMouseUp)

    return () => {
      map.off("mousedown", onMouseDown)
      map.off("mousemove", onMouseMove)
      map.off("mouseup",   onMouseUp)
      map.dragging.enable()
      map.getContainer().style.cursor = ""
      if (rect) { map.removeLayer(rect); rect = null }
    }
  }, [enabled, map, onBboxSelect])

  return null
}

function FocusController({ focusTarget }) {
  const map = useMap()

  useEffect(() => {
    if (!focusTarget) return

    if (focusTarget.bounds) {
      map.flyToBounds(bboxToRectangleBounds(focusTarget.bounds), {
        padding: [48, 48],
        maxZoom: 17,
      })
      return
    }

    if (focusTarget.lat != null && focusTarget.lng != null) {
      map.flyTo([focusTarget.lat, focusTarget.lng], Math.max(map.getZoom(), 16), {
        duration: 1.2,
      })
    }
  }, [focusTarget, map])

  return null
}

function SearchResultOverlay({ searchResult, scanBbox, onOpenStreetView }) {
  if (!searchResult?.location) return null

  const center = [
    Number(searchResult.location.lat),
    Number(searchResult.location.lng),
  ]

  const streetViewLocation = searchResult.street_view?.location || searchResult.location
  const streetViewAvailable = Boolean(searchResult.street_view?.available)

  return (
    <>
      {!scanBbox && searchResult.scan_bbox && (
        <Rectangle
          bounds={bboxToRectangleBounds(searchResult.scan_bbox)}
          pathOptions={{
            color: "#2563eb",
            weight: 1.5,
            dashArray: "6 4",
            fillOpacity: 0.04,
            interactive: false,
          }}
        />
      )}

      <Circle
        center={center}
        radius={70}
        pathOptions={{
          color: "#2563eb",
          fillColor: "#60a5fa",
          fillOpacity: 0.14,
          weight: 1.5,
          interactive: false,
        }}
      />

      <CircleMarker
        center={center}
        radius={8}
        pathOptions={{
          color: "#1d4ed8",
          fillColor: "#60a5fa",
          fillOpacity: 0.95,
          weight: 2,
        }}
      >
        <Popup className="pothole-popup">
          <div className="popup-inner">
            <span className="popup-sev" style={{ background: "#2563eb" }}>
              SEARCH
            </span>
            <p><strong>Location:</strong> {searchResult.formatted_address}</p>
            <p>
              <strong>Street View:</strong>{" "}
              {streetViewAvailable ? "available" : (searchResult.street_view?.status || "unavailable")}
            </p>
            {searchResult.street_view?.date && (
              <p className="popup-time">Captured: {searchResult.street_view.date}</p>
            )}
            {streetViewAvailable && (
              <button
                className="sv-btn"
                onClick={() => onOpenStreetView(Number(streetViewLocation.lat), Number(streetViewLocation.lng))}
              >
                📷 Street View
              </button>
            )}
          </div>
        </Popup>
      </CircleMarker>
    </>
  )
}
// ─── Main MapView ─────────────────────────────────────────────────────────────
function MapView({
  onStatsUpdate,
  since,
  drawMode,
  onBboxSelect,
  onMapBoundsChange,
  scanBbox,
  refreshKey,
  focusTarget,
  searchResult,
  streetViewRequest,
}) {
  const [potholes, setPotholes] = useState([])
  const [zoom, setZoom] = useState(13)
  const [loadedKey, setLoadedKey] = useState(null)
  const [errorState, setErrorState] = useState(null)
  const [manualSvCoords, setManualSvCoords] = useState(null)
  const [dismissedRequestToken, setDismissedRequestToken] = useState(null)
  const [resolvedFadeStarts, setResolvedFadeStarts] = useState({})
  const [fadeNowMs, setFadeNowMs] = useState(() => Date.now())
  const resolvedStateRef = useRef(new Map())
  const resolvedHydratedRef = useRef(false)

  const center = [21.2514, 81.6296]
  const loadKey = `${since || "all"}:${refreshKey}`
  const requestToken = streetViewRequest
    ? `${streetViewRequest.openedAt || "manual"}:${streetViewRequest.lat}:${streetViewRequest.lng}:${streetViewRequest.heading ?? ""}`
    : null

  const requestedSvCoords = (
    streetViewRequest?.lat != null
    && streetViewRequest?.lng != null
    && requestToken !== dismissedRequestToken
  )
    ? {
        lat: Number(streetViewRequest.lat),
        lng: Number(streetViewRequest.lng),
        heading: Number.isFinite(Number(streetViewRequest.heading)) ? Number(streetViewRequest.heading) : 0,
      }
    : null

  const activeSvCoords = manualSvCoords || requestedSvCoords
  const loading = loadedKey !== loadKey && (!errorState || errorState.key !== loadKey)
  const error = errorState && errorState.key === loadKey ? errorState.message : null

  const renderedPotholes = useMemo(() => {
    const rows = []

    for (const pothole of potholes) {
      const key = getPotholeRenderKey(pothole)
      const resolved = isResolvedPothole(pothole)

      if (!resolved) {
        rows.push({ ...pothole, _render_key: key, _render_opacity: 1 })
        continue
      }

      const fadeStart = Number(resolvedFadeStarts[key])
      if (!Number.isFinite(fadeStart)) {
        continue
      }

      const elapsed = Math.max(0, fadeNowMs - fadeStart)
      const progress = Math.min(1, elapsed / RESOLVED_FADE_MS)
      const opacity = 1 - progress

      if (opacity <= 0) {
        continue
      }

      rows.push({ ...pothole, _render_key: key, _render_opacity: opacity })
    }

    return rows
  }, [potholes, resolvedFadeStarts, fadeNowMs])

  const openStreetView = (lat, lng, heading = 0) => {
    const nextLat = Number(lat)
    const nextLng = Number(lng)
    const nextHeading = Number(heading)
    if (!Number.isFinite(nextLat) || !Number.isFinite(nextLng)) return

    if (requestToken) {
      setDismissedRequestToken(requestToken)
    }

    setManualSvCoords({
      lat: nextLat,
      lng: nextLng,
      heading: Number.isFinite(nextHeading) ? nextHeading : 0,
    })
  }

  const closeStreetView = () => {
    if (manualSvCoords) {
      setManualSvCoords(null)
      return
    }
    if (requestToken) {
      setDismissedRequestToken(requestToken)
    }
  }

  useEffect(() => {
    const url = since
      ? `${API_BASE}/potholes?since=${since}`
      : `${API_BASE}/potholes`

    let cancelled = false
    resolvedStateRef.current = new Map()
    resolvedHydratedRef.current = false

    const fetchPotholeData = () => {
      fetch(url)
        .then(res => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`)
          return res.json()
        })
        .then(data => {
          if (cancelled) return

          const now = Date.now()
          const nextResolvedMap = new Map()
          const newlyResolvedKeys = []

          for (const pothole of data) {
            const key = getPotholeRenderKey(pothole)
            const resolved = isResolvedPothole(pothole)
            nextResolvedMap.set(key, resolved)

            const wasResolved = resolvedStateRef.current.get(key) === true
            if (resolved && !wasResolved) {
              newlyResolvedKeys.push(key)
            }
          }

          const skipFadeForThisBatch = !resolvedHydratedRef.current
          resolvedHydratedRef.current = true
          resolvedStateRef.current = nextResolvedMap

          setResolvedFadeStarts(prev => {
            const next = { ...prev }

            if (!skipFadeForThisBatch) {
              for (const key of newlyResolvedKeys) {
                if (!next[key]) {
                  next[key] = now
                }
              }
            }

            for (const key of Object.keys(next)) {
              const stillExists = nextResolvedMap.has(key)
              const stillResolved = nextResolvedMap.get(key) === true
              if (!stillExists || !stillResolved) {
                delete next[key]
              }
            }

            return next
          })

          setFadeNowMs(now)
          setPotholes(data)
          setLoadedKey(loadKey)
          setErrorState(null)

          const activeRows = data.filter(p => !isResolvedPothole(p))
          const total = activeRows.length
          const severe = activeRows.filter(p => normaliseSeverity(p.severity) === "high").length
          const moderate = activeRows.filter(p => normaliseSeverity(p.severity) === "medium").length
          onStatsUpdate?.({ total, severe, moderate })
        })
        .catch(err => {
          if (cancelled) return
          console.error("Failed to fetch potholes:", err)
          setErrorState({ key: loadKey, message: err.message })
        })
    }

    fetchPotholeData()
    const pollId = setInterval(fetchPotholeData, REALTIME_POLL_MS)

    return () => {
      cancelled = true
      clearInterval(pollId)
    }
  }, [since, onStatsUpdate, refreshKey, loadKey])

  useEffect(() => {
    if (!Object.keys(resolvedFadeStarts).length) return

    const tickId = setInterval(() => {
      const now = Date.now()
      setFadeNowMs(now)

      setResolvedFadeStarts(prev => {
        let changed = false
        const next = { ...prev }

        for (const key of Object.keys(next)) {
          const startedAt = Number(next[key])
          if (!Number.isFinite(startedAt)) {
            delete next[key]
            changed = true
            continue
          }

          if (now - startedAt >= RESOLVED_FADE_MS) {
            delete next[key]
            changed = true
          }
        }

        return changed ? next : prev
      })
    }, FADE_FRAME_MS)

    return () => clearInterval(tickId)
  }, [resolvedFadeStarts])

  return (
    <>
      {loading && (
        <div className="map-status">Loading pothole data…</div>
      )}
      {error && (
        <div className="map-status error">Backend unreachable — showing empty map</div>
      )}

      <MapContainer
        center={center}
        zoom={zoom}
        className="map-canvas"
        zoomControl={false}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        />

        <FocusController focusTarget={focusTarget} />
        <ZoomTracker onZoomChange={setZoom} />
        <BoundsTracker onBoundsChange={onMapBoundsChange} />
        <HeatLayer potholes={renderedPotholes} zoom={zoom} />
        <DiscreteMarkers
          potholes={renderedPotholes}
          zoom={zoom}
          onOpenStreetView={openStreetView}
        />
        <SearchResultOverlay
          searchResult={searchResult}
          scanBbox={scanBbox}
          onOpenStreetView={openStreetView}
        />

        {/* Bounding box draw tool */}
        <DrawBbox enabled={drawMode} onBboxSelect={onBboxSelect} />

        {/* Persistent bbox rectangle after selection */}
        {scanBbox && (
          <Rectangle
            bounds={bboxToRectangleBounds(scanBbox)}
            pathOptions={{
              color: "#22c55e", weight: 2, dashArray: "8 4",
              fillOpacity: 0.06, interactive: false,
            }}
          />
        )}
      </MapContainer>

      {activeSvCoords && (
        <StreetViewModal
          lat={activeSvCoords.lat}
          lng={activeSvCoords.lng}
          initialHeading={activeSvCoords.heading || 0}
          onClose={closeStreetView}
        />
      )}
    </>
  )
}

export default MapView
