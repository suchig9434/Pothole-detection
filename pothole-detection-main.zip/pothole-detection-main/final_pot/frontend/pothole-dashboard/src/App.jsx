import { useState, useEffect, useCallback, useRef } from "react"
import MapView from "./MapView"
import "./App.css"

const API_BASE = "http://127.0.0.1:5000"
const PRIORITY_QUEUE_REFRESH_MS = 12000

function formatCoord(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n.toFixed(5) : "—"
}

function formatConfidence(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n.toFixed(3) : "0.000"
}

function formatSeverity(value) {
  return String(value || "unknown").toUpperCase()
}

function formatPotholeIds(ids, maxVisible = 3) {
  if (!Array.isArray(ids) || ids.length === 0) return ""
  const clean = ids.map(value => String(value).trim()).filter(Boolean)
  if (clean.length === 0) return ""
  if (clean.length <= maxVisible) return clean.join(", ")
  const shown = clean.slice(0, maxVisible).join(", ")
  return `${shown}, +${clean.length - maxVisible} more`
}

function getFindingImageSrc(finding) {
  if (!finding) return null
  if (finding.image_url) return finding.image_url
  if (finding.image_base64) {
    return `data:${finding.image_content_type || "image/jpeg"};base64,${finding.image_base64}`
  }
  return null
}

function App() {
  const [uiVisible, setUiVisible] = useState(true)
  const [stats, setStats] = useState({ total: "—", severe: "—", moderate: "—" })
  const [sinceFilter, setSinceFilter] = useState("24h")
  const [searchQuery, setSearchQuery] = useState("")
  const [searchLoading, setSearchLoading] = useState(false)
  const [searchError, setSearchError] = useState(null)
  const [searchResult, setSearchResult] = useState(null)
  const [mapFocus, setMapFocus] = useState(null)
  const [mapBounds, setMapBounds] = useState(null)
  const [streetViewRequest, setStreetViewRequest] = useState(null)

  // ── Scan states ─────────────────────────────────────────────────────────
  const [drawMode,   setDrawMode]   = useState(false)
  const [scanBbox,   setScanBbox]   = useState(null)
  const [scanning,   setScanning]   = useState(false)
  const [scanStatus, setScanStatus] = useState(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [activeScanSessionId, setActiveScanSessionId] = useState(null)
  const [newScanFindings, setNewScanFindings] = useState([])
  const [selectedFinding, setSelectedFinding] = useState(null)
  const [scanDialogVisible, setScanDialogVisible] = useState(false)
  const [priorityQueueItems, setPriorityQueueItems] = useState([])
  const [priorityQueueLoading, setPriorityQueueLoading] = useState(false)
  const [priorityQueueError, setPriorityQueueError] = useState(null)
  const scanDialogHideTimerRef = useRef(null)

  const clearScanDialogTimer = useCallback(() => {
    if (!scanDialogHideTimerRef.current) return
    clearTimeout(scanDialogHideTimerRef.current)
    scanDialogHideTimerRef.current = null
  }, [])

  const scheduleScanDialogHide = useCallback((delayMs = 4000) => {
    clearScanDialogTimer()
    scanDialogHideTimerRef.current = setTimeout(() => {
      setScanDialogVisible(false)
      scanDialogHideTimerRef.current = null
    }, delayMs)
  }, [clearScanDialogTimer])

  useEffect(() => () => {
    clearScanDialogTimer()
  }, [clearScanDialogTimer])

  const applyScanBbox = useCallback((bbox) => {
    setScanBbox(bbox)
    setDrawMode(false)
  }, [])

  const handleBboxSelect = useCallback((bbox) => {
    applyScanBbox(bbox)
  }, [applyScanBbox])

  const handleSearchSubmit = async (event) => {
    event.preventDefault()

    const query = searchQuery.trim()
    if (!query || searchLoading) return

    setSearchLoading(true)
    setSearchError(null)

    try {
      const params = new URLSearchParams({ q: query })
      const response = await fetch(`${API_BASE}/maps/search?${params.toString()}`)
      const payload = await response.json().catch(() => ({}))

      if (!response.ok) {
        throw new Error(payload.error || "Search failed")
      }

      setSearchResult(payload)
      setMapFocus({
        lat: Number(payload.location.lat),
        lng: Number(payload.location.lng),
        bounds: payload.map_bounds || null,
        label: payload.formatted_address,
      })
    } catch (error) {
      setSearchResult(null)
      setSearchError(error.message || "Search failed")
    } finally {
      setSearchLoading(false)
    }
  }

  const handleClearSearch = useCallback(() => {
    setSearchQuery("")
    setSearchError(null)
    setSearchResult(null)
    setMapFocus(null)
  }, [])

  const handleUseSearchArea = useCallback(() => {
    if (!searchResult?.scan_bbox) return
    applyScanBbox(searchResult.scan_bbox)
  }, [applyScanBbox, searchResult])

  const handleOpenSearchStreetView = useCallback(() => {
    const streetViewLocation = searchResult?.street_view?.location || searchResult?.location
    if (!streetViewLocation) return

    setStreetViewRequest({
      lat: Number(streetViewLocation.lat),
      lng: Number(streetViewLocation.lng),
      openedAt: Date.now(),
    })
  }, [searchResult])

  const handleMapBoundsChange = useCallback((bounds) => {
    if (!bounds) return

    setMapBounds((prev) => {
      if (
        prev
        && prev.north === bounds.north
        && prev.south === bounds.south
        && prev.east === bounds.east
        && prev.west === bounds.west
      ) {
        return prev
      }
      return bounds
    })
  }, [])

  const fetchPriorityQueue = useCallback(async () => {
    if (!mapBounds) return

    setPriorityQueueLoading(true)
    setPriorityQueueError(null)

    try {
      const params = new URLSearchParams({
        limit: "8",
        north: String(mapBounds.north),
        south: String(mapBounds.south),
        east: String(mapBounds.east),
        west: String(mapBounds.west),
      })
      const response = await fetch(`${API_BASE}/potholes/priority-queue?${params.toString()}`)
      const payload = await response.json().catch(() => ({}))

      if (!response.ok) {
        throw new Error(payload.error || "Failed to load priority queue")
      }

      const items = Array.isArray(payload.items) ? payload.items : []
      setPriorityQueueItems(items)
    } catch (error) {
      setPriorityQueueItems([])
      setPriorityQueueError(error.message || "Failed to load priority queue")
    } finally {
      setPriorityQueueLoading(false)
    }
  }, [mapBounds])

  const handleStartScan = async () => {
    if (!scanBbox) return
    try {
      const r = await fetch(`${API_BASE}/scan/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          north: scanBbox.north, south: scanBbox.south,
          east:  scanBbox.east,  west:  scanBbox.west,
        }),
      })
      const payload = await r.json().catch(() => ({}))

      if (r.ok) {
        setScanning(true)
        setScanStatus(null)
        clearScanDialogTimer()
        setScanDialogVisible(true)
        setSelectedFinding(null)
        setNewScanFindings([])
        setActiveScanSessionId(payload.session_id || null)
      } else {
        alert(payload.error || "Failed to start scan")
      }
    } catch {
      alert("Backend unreachable — is the Flask server running?")
    }
  }

  const handleStopScan = async () => {
    await fetch(`${API_BASE}/scan/stop`, { method: "POST" })
    setScanning(false)
  }

  // Poll scan status every 1.5 s while a scan is running
  useEffect(() => {
    if (!scanning) return
    const id = setInterval(async () => {
      try {
        const r    = await fetch(`${API_BASE}/scan/status`)
        const data = await r.json()
        setScanStatus(data)

        if (data.session_id) {
          setActiveScanSessionId(data.session_id)
        }

        if (Array.isArray(data.findings)) {
          setNewScanFindings(data.findings)
        }

        if (!data.running) {
          setScanning(false)
          setRefreshKey(k => k + 1)   // re-fetch pothole layer
          scheduleScanDialogHide(4500)
        } else {
          clearScanDialogTimer()
          setScanDialogVisible(true)
        }
      } catch {
        // ignore transient network errors
      }
    }, 1500)
    return () => clearInterval(id)
  }, [scanning, clearScanDialogTimer, scheduleScanDialogHide])

  useEffect(() => {
    if (scanning) return
    fetchPriorityQueue()
  }, [scanning, refreshKey, fetchPriorityQueue])

  useEffect(() => {
    if (scanning || !mapBounds) return

    const timerId = setInterval(() => {
      fetchPriorityQueue()
    }, PRIORITY_QUEUE_REFRESH_MS)

    return () => clearInterval(timerId)
  }, [scanning, mapBounds, fetchPriorityQueue])

  const districtName = searchResult?.district || "Raipur"
  const localityName = searchResult?.locality || "All Areas"
  const searchHasStreetView = Boolean(searchResult?.street_view?.available)
  const headerStatus = scanning ? "SCANNING" : searchLoading ? "SEARCH" : "LIVE"
  const rightPaneMode = scanning ? "scan" : "priority"

  return (
    <div className="root">
      {/* Full-page map */}
      <div className="map-layer">
        <MapView
          onStatsUpdate={setStats}
          since={sinceFilter}
          drawMode={drawMode}
          onBboxSelect={handleBboxSelect}
          onMapBoundsChange={handleMapBoundsChange}
          scanBbox={scanBbox}
          refreshKey={refreshKey}
          focusTarget={mapFocus}
          searchResult={searchResult}
          streetViewRequest={streetViewRequest}
        />
      </div>

      {uiVisible && (
        <>
          {/* Header */}
          <header className="header">
            <div className="header-logo">
              <span className="header-dot" />
              <span className="header-title">Autonomous Pothole Intelligence</span>
            </div>

            <form className="header-search" onSubmit={handleSearchSubmit}>
              <svg className="search-icon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input
                className="search-input"
                type="text"
                placeholder="Search road, area, or lat,lng"
                aria-label="Search"
                value={searchQuery}
                onChange={event => setSearchQuery(event.target.value)}
                disabled={searchLoading}
              />
              {searchQuery && (
                <button
                  type="button"
                  className="search-inline-btn search-inline-clear"
                  onClick={handleClearSearch}
                  aria-label="Clear search"
                  disabled={searchLoading}
                >
                  ✕
                </button>
              )}
              <button
                type="submit"
                className="search-inline-btn search-inline-submit"
                disabled={searchLoading || !searchQuery.trim()}
              >
                {searchLoading ? "..." : "Go"}
              </button>
            </form>

            <div className="header-meta">{headerStatus}</div>
          </header>

          {/* Left Pane */}
          <aside className="left-pane">
            <section className="pane-section district-section">
              <p className="label-sub">District</p>
              <h2 className="district-name">{districtName}</h2>
              <p className="label-sub locality-label">Locality</p>
              <p className="locality-name">{localityName}</p>
            </section>

            <div className="pane-divider" />

            <section className="pane-section search-result-section">
              <p className="label-sub" style={{ marginBottom: 10 }}>Location Search</p>

              {!searchResult && !searchError && (
                <p className="search-result-feedback">
                  Search a road, neighbourhood, or coordinates to focus the map and prepare a Street View scan.
                </p>
              )}

              {searchError && (
                <p className="search-result-feedback error">{searchError}</p>
              )}

              {searchResult && (
                <div className="search-result-card">
                  <p className="search-result-title">{searchResult.formatted_address}</p>
                  <p className="search-result-meta">
                    {searchHasStreetView
                      ? `Street View available${searchResult.street_view.date ? ` • ${searchResult.street_view.date}` : ""}`
                      : `Street View status: ${searchResult.street_view?.status || "unknown"}`}
                  </p>
                  <p className="search-result-coords">
                    {Number(searchResult.location.lat).toFixed(5)}, {Number(searchResult.location.lng).toFixed(5)}
                  </p>
                  <p className="search-result-hint">
                    Suggested scan box: {searchResult.scan_radius_m} m around the nearest Street View point.
                  </p>

                  <div className="search-result-actions">
                    <button className="search-primary-btn" onClick={handleUseSearchArea}>
                      Use Search Area
                    </button>
                    <button
                      className="search-secondary-btn"
                      onClick={handleOpenSearchStreetView}
                      disabled={!searchHasStreetView}
                    >
                      Street View
                    </button>
                  </div>
                </div>
              )}
            </section>

            <div className="pane-divider" />

            {/* Time filter */}
            <section className="pane-section filter-section">
              <p className="label-sub" style={{ marginBottom: 10 }}>Time Window</p>
              <div className="filter-pills">
                {["24h", "7d", "30d"].map(opt => (
                  <button
                    key={opt}
                    className={`filter-pill ${sinceFilter === opt ? "active" : ""}`}
                    onClick={() => setSinceFilter(opt)}
                  >
                    {opt === "24h" ? "Last 24h" : opt === "7d" ? "Last 7 days" : "Last 30 days"}
                  </button>
                ))}
              </div>
            </section>

            <div className="pane-divider" />

            {/* ── Road Scan ───────────────────────────────────────── */}
            <section className="pane-section scan-section">
              <p className="label-sub" style={{ marginBottom: 10 }}>Road Scan</p>

              {!scanning && !scanBbox && (
                <button
                  className={`scan-draw-btn${drawMode ? " active" : ""}`}
                  onClick={() => setDrawMode(d => !d)}
                >
                  {drawMode ? "✕ Cancel" : "⬚ Draw Scan Area"}
                </button>
              )}

              {!scanning && scanBbox && (
                <div className="scan-ready">
                  <p className="scan-ready-label">Area selected ✓</p>
                  <div className="scan-ready-actions">
                    <button className="scan-start-btn" onClick={handleStartScan}>
                      ▶ Start Scan
                    </button>
                    <button
                      className="scan-clear-btn"
                      onClick={() => setScanBbox(null)}
                    >
                      Clear
                    </button>
                  </div>
                </div>
              )}

              {scanning && (
                <button className="scan-stop-btn" onClick={handleStopScan}>
                  ⬛ Stop Scan
                </button>
              )}
            </section>

            <div className="pane-divider" />

            <section className="pane-section stats-section">
              <div className="stat-total">
                <span className="stat-number">{stats.total}</span>
                <span className="stat-label">Total Cases</span>
              </div>

              <div className="pane-divider" />

              <div className="stat-row">
                <div className="stat-dot severe" />
                <div className="stat-text">
                  <span className="stat-count">{stats.severe}</span>
                  <span className="stat-tag">Severe Cases</span>
                </div>
              </div>

              <div className="stat-row">
                <div className="stat-dot moderate" />
                <div className="stat-text">
                  <span className="stat-count">{stats.moderate}</span>
                  <span className="stat-tag">Moderate Cases</span>
                </div>
              </div>
            </section>

            {/* Zoom guide */}
            <div className="pane-divider" />
            <section className="pane-section zoom-legend">
              <p className="label-sub" style={{ marginBottom: 10 }}>Map Layers</p>
              <div className="legend-row">
                <span className="legend-icon cloud-large" />
                <span className="legend-text">District view — severity cloud</span>
              </div>
              <div className="legend-row">
                <span className="legend-icon cloud-small" />
                <span className="legend-text">Neighbourhood — focused cloud</span>
              </div>
              <div className="legend-row">
                <span className="legend-icon dot-marker" />
                <span className="legend-text">Street level — discrete points</span>
              </div>
            </section>

            <div className="pane-footer">
              <button
                className="close-btn"
                onClick={() => setUiVisible(false)}
                title="Hide UI"
                aria-label="Hide UI"
              >
                ✕
              </button>
            </div>
          </aside>

          <aside className="right-pane">
            <section className="pane-section right-pane-heading">
              <p className="label-sub">{rightPaneMode === "scan" ? "Latest Scan Session" : "Complaint Queue"}</p>
              <h3 className="right-pane-title">{rightPaneMode === "scan" ? "New Street View Finds" : "Priority Queue"}</h3>
              <p className="right-pane-subtitle">
                {rightPaneMode === "scan"
                  ? newScanFindings.length > 0
                    ? `${newScanFindings.length} new pothole${newScanFindings.length > 1 ? "s" : ""} from this scan.`
                    : activeScanSessionId
                      ? "No potholes found in this scan session yet."
                      : "Start a scan to build a fresh detection gallery."
                  : priorityQueueItems.length > 0
                    ? `${priorityQueueItems.length} clusters ranked for complaint dispatch.`
                    : priorityQueueLoading
                      ? "Loading complaint priority queue..."
                      : "No pending complaint clusters right now."}
              </p>
              {rightPaneMode === "priority" && (
                <p className="right-pane-subtitle">
                  Queue refreshes every {Math.round(PRIORITY_QUEUE_REFRESH_MS / 1000)}s. Acknowledged potholes are removed automatically.
                </p>
              )}
              {rightPaneMode === "scan" && activeScanSessionId && (
                <p className="right-pane-session">Session: {activeScanSessionId.slice(0, 8)}</p>
              )}
            </section>

            <div className="pane-divider" />

            <section className="pane-section right-pane-gallery">
              {rightPaneMode === "scan" ? (
                newScanFindings.length === 0 ? (
                  <p className="right-pane-empty">
                    New pothole images from this running scan appear here.
                  </p>
                ) : (
                  <div className="finding-list">
                    {newScanFindings.map((finding, idx) => {
                      const lat = Number(finding.latitude)
                      const lng = Number(finding.longitude)
                      const hasCoords = Number.isFinite(lat) && Number.isFinite(lng)
                      const imageSrc = getFindingImageSrc(finding)
                      const hasImage = Boolean(imageSrc)
                      const canInteract = hasCoords || hasImage
                      const key = `${finding.scan_session_id || activeScanSessionId || "scan"}-${idx}`

                      return (
                        <button
                          type="button"
                          key={key}
                          className={`finding-card${canInteract ? "" : " disabled"}`}
                          onClick={() => {
                            if (hasCoords) {
                              setMapFocus({
                                lat,
                                lng,
                                bounds: null,
                                label: "New scan finding",
                              })
                            }
                            if (hasImage) setSelectedFinding(finding)
                          }}
                          disabled={!canInteract}
                          title={hasImage ? "Focus map and view pothole image" : "Focus map on this pothole"}
                        >
                          <div className="finding-thumb">
                            {hasImage ? (
                              <img
                                src={imageSrc}
                                alt={`Detected pothole ${idx + 1}`}
                                loading="lazy"
                              />
                            ) : (
                              <div className="finding-thumb-placeholder">No image</div>
                            )}
                          </div>

                          <div className="finding-info">
                            <p className="finding-severity">{formatSeverity(finding.severity)}</p>
                            <p className="finding-coords">
                              {formatCoord(finding.latitude)}, {formatCoord(finding.longitude)}
                            </p>
                            <p className="finding-meta">
                              Confidence {formatConfidence(finding.confidence)} • {String(finding.source || "street_view")}
                            </p>
                          </div>
                        </button>
                      )
                    })}
                  </div>
                )
              ) : priorityQueueLoading ? (
                <p className="right-pane-empty">Loading complaint priority queue...</p>
              ) : priorityQueueError ? (
                <p className="right-pane-empty">{priorityQueueError}</p>
              ) : priorityQueueItems.length === 0 ? (
                <p className="right-pane-empty">No pending potholes are waiting for complaint dispatch.</p>
              ) : (
                <div className="finding-list">
                  {priorityQueueItems.map((item, idx) => {
                    const lat = Number(item.latitude)
                    const lng = Number(item.longitude)
                    const hasCoords = Number.isFinite(lat) && Number.isFinite(lng)
                    const clusterCount = Math.max(1, Number(item.cluster_count) || 1)
                    const potholeIdsText = formatPotholeIds(item.pothole_ids)

                    return (
                      <button
                        type="button"
                        key={`priority-${item.cluster_id ?? idx}`}
                        className={`finding-card${hasCoords ? "" : " disabled"}`}
                        onClick={() => {
                          if (!hasCoords) return
                          setMapFocus({
                            lat,
                            lng,
                            bounds: null,
                            label: `Priority cluster #${idx + 1}`,
                          })
                        }}
                        disabled={!hasCoords}
                        title="Focus map on this priority cluster"
                      >
                        <div className="finding-info">
                          <p className="finding-severity">#{idx + 1} {formatSeverity(item.severity)}</p>
                          <p className="finding-coords">
                            Lat {formatCoord(item.latitude)} • Long {formatCoord(item.longitude)}
                          </p>
                          <p className="finding-meta">
                            Severity Score {formatConfidence(item.severity_score)} • {clusterCount} pothole{clusterCount > 1 ? "s" : ""}
                          </p>
                          {potholeIdsText && (
                            <p className="finding-meta">
                              IDs: {potholeIdsText}
                            </p>
                          )}
                        </div>
                      </button>
                    )
                  })}
                </div>
              )}
            </section>
          </aside>
        </>
      )}

      {!uiVisible && (
        <button
          className="reveal-btn"
          onClick={() => setUiVisible(true)}
          title="Show UI"
          aria-label="Show UI"
        >
          {">"}
        </button>
      )}

      {/* ── Scan progress dialog (fixed bottom-centre) ──────────── */}
      {scanDialogVisible && scanStatus && (
        <div className="scan-dialog">
          <div className="scan-dialog-top">
            <span className="scan-dialog-title">
              {scanStatus.running ? "Scanning road network…" : "Scan complete"}
            </span>
            {!scanStatus.running && (
              <button
                className="scan-dialog-close"
                onClick={() => {
                  clearScanDialogTimer()
                  setScanDialogVisible(false)
                  setScanStatus(null)
                  setScanBbox(null)
                }}
              >
                ✕
              </button>
            )}
          </div>

          {scanStatus.error && (
            <p className="scan-dialog-error">{scanStatus.error}</p>
          )}

          <div className="scan-progress-track">
            {scanStatus.total === -1 ? (
              <div className="scan-progress-indeterminate" />
            ) : (
              <div
                className="scan-progress-fill"
                style={{
                  width: `${scanStatus.total > 0
                    ? Math.min(100, Math.round((scanStatus.done / scanStatus.total) * 100))
                    : 100}%`
                }}
              />
            )}
          </div>

          <div className="scan-dialog-row">
            <span className="scan-dialog-pts">
              {scanStatus.total === -1
                ? "Loading road network…"
                : `${scanStatus.done} / ${scanStatus.total} points`}
            </span>
            <span className="scan-dialog-found">🕳 {scanStatus.found} found</span>
          </div>

          {scanStatus.current_lat != null && (
            <p className="scan-dialog-coords">
              📍 {Number(scanStatus.current_lat).toFixed(5)},
              {" "}{Number(scanStatus.current_lng).toFixed(5)}
            </p>
          )}
        </div>
      )}

      {selectedFinding && (
        <div
          className="finding-overlay"
          onClick={event => {
            if (event.target === event.currentTarget) {
              setSelectedFinding(null)
            }
          }}
        >
          <div className="finding-modal">
            <div className="finding-modal-top">
              <span className="finding-modal-title">New Street View Detection</span>
              <button
                className="finding-modal-close"
                onClick={() => setSelectedFinding(null)}
                aria-label="Close image preview"
              >
                ✕
              </button>
            </div>

            {getFindingImageSrc(selectedFinding) ? (
              <img
                className="finding-modal-image"
                src={getFindingImageSrc(selectedFinding)}
                alt="Detected pothole"
              />
            ) : (
              <p className="finding-modal-empty">No image available for this detection.</p>
            )}

            <div className="finding-modal-meta">
              <p>
                <strong>Coordinates:</strong> {formatCoord(selectedFinding.latitude)}, {formatCoord(selectedFinding.longitude)}
              </p>
              <p>
                <strong>Severity:</strong> {String(selectedFinding.severity || "unknown").toUpperCase()}
              </p>
              <p>
                <strong>Source:</strong> {String(selectedFinding.source || "street_view")}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
