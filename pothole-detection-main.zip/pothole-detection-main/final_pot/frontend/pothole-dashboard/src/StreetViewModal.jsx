/**
 * StreetViewModal
 *
 * Shows a Google Street View iframe for the given lat/lng.
 *
 * How to enable:
 *   1. Get a Google Maps API key with the "Street View Static API" enabled.
 *   2. Create  final_pot/frontend/pothole-dashboard/.env.local
 *      and add:  VITE_GMAPS_KEY=AIza...yourkey...
 *   3. Restart the Vite dev server.
 *
 * Without a key the modal shows a direct Maps.google.com link instead
 * (no iframe, no API quota used).
 */
import { useEffect, useRef, useState } from "react"

const API_BASE = "http://127.0.0.1:5000"

const GMAPS_KEY = import.meta.env.VITE_GMAPS_KEY || ""
const SHOW_STREETVIEW_EMBED = ["1", "true", "yes", "on"].includes(
  String(import.meta.env.VITE_SHOW_STREETVIEW_EMBED || "0").toLowerCase()
)
const HEADING_OPTIONS = [0, 90, 180, 270]
const DETECTION_FOV = 60


function formatSeverity(value) {
  if (!value) return "UNKNOWN"
  return String(value).toUpperCase()
}

function normalizeHeading(value) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return ((n % 360) + 360) % 360
}

export default function StreetViewModal({ lat, lng, initialHeading = 0, onClose }) {
  const overlayRef = useRef(null)
  const [heading, setHeading] = useState(() => normalizeHeading(initialHeading))
  const [refreshTick, setRefreshTick] = useState(0)
  const [detection, setDetection] = useState(null)
  const [detectLoading, setDetectLoading] = useState(true)
  const [detectError, setDetectError] = useState(null)

  // Close on Escape key
  useEffect(() => {
    const handler = e => { if (e.key === "Escape") onClose() }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [onClose])

  useEffect(() => {
    setHeading(normalizeHeading(initialHeading))
    setRefreshTick(0)
    setDetection(null)
    setDetectError(null)
  }, [lat, lng, initialHeading])

  useEffect(() => {
    let cancelled = false

    async function runDetection() {
      setDetectLoading(true)
      setDetectError(null)

      try {
        const response = await fetch(`${API_BASE}/scan/detect-street-view`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            lat,
            lng,
            heading,
            fov: DETECTION_FOV,
            pitch: 0,
          }),
        })

        const payload = await response.json().catch(() => ({}))
        if (!response.ok) {
          throw new Error(payload.error || "Street View detection failed")
        }

        if (!cancelled) {
          setDetection(payload)
        }
      } catch (error) {
        if (!cancelled) {
          setDetection(null)
          setDetectError(error.message || "Street View detection failed")
        }
      } finally {
        if (!cancelled) {
          setDetectLoading(false)
        }
      }
    }

    runDetection()
    return () => {
      cancelled = true
    }
  }, [lat, lng, heading, refreshTick])

  // Close on backdrop click
  const handleBackdrop = e => {
    if (e.target === overlayRef.current) onClose()
  }

  const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}&layer=c&z=17`
  const showEmbedPanel = SHOW_STREETVIEW_EMBED && Boolean(GMAPS_KEY)
  const imageSrc = detection?.image_base64
    ? `data:${detection.image_content_type || "image/jpeg"};base64,${detection.image_base64}`
    : null

  return (
    <div className="sv-overlay" ref={overlayRef} onClick={handleBackdrop}>
      <div className={`sv-modal${showEmbedPanel ? "" : " single-pane"}`}>
        <div className="sv-modal-header">
          <span className="sv-modal-title">
            <span className="sv-dot" />
            Street View — {lat.toFixed(5)}, {lng.toFixed(5)}
          </span>
          <button className="sv-close" onClick={onClose} aria-label="Close Street View">✕</button>
        </div>

        <div className={`sv-content${showEmbedPanel ? "" : " single-pane"}`}>
          {showEmbedPanel && (
            <div className="sv-frame-wrap">
              <iframe
                title="Google Street View"
                src={`https://www.google.com/maps/embed/v1/streetview?key=${GMAPS_KEY}&location=${lat},${lng}&heading=${heading}&pitch=0&fov=${DETECTION_FOV}`}
                allowFullScreen
              />
            </div>
          )}

          <aside className={`sv-detect-pane${showEmbedPanel ? "" : " single-pane"}`}>
            <div className="sv-detect-top">
              <p className="sv-detect-title">Model Detection</p>
              <button
                className="sv-detect-rerun"
                onClick={() => setRefreshTick(t => t + 1)}
                disabled={detectLoading}
              >
                Re-run
              </button>
            </div>

            {!showEmbedPanel && (
              <a className="sv-open-link" href={googleMapsUrl} target="_blank" rel="noopener noreferrer">
                Open Street View in Google Maps ↗
              </a>
            )}

            <p className="sv-detect-label">Heading</p>
            <div className="sv-heading-grid">
              {HEADING_OPTIONS.map(opt => (
                <button
                  key={opt}
                  className={`sv-heading-btn${heading === opt ? " active" : ""}`}
                  onClick={() => setHeading(opt)}
                  disabled={detectLoading && heading === opt}
                >
                  {opt}°
                </button>
              ))}
            </div>

            {detectLoading && (
              <p className="sv-detect-status">Running YOLO + road segmentation on Street View image...</p>
            )}

            {detectError && !detectLoading && (
              <p className="sv-detect-error">{detectError}</p>
            )}

            {!detectLoading && !detectError && detection && (
              <div className="sv-detect-result">
                <div className="sv-detect-status-row">
                  <p className={`sv-detect-pill ${detection.found ? "found" : "none"}`}>
                    {detection.found ? "POTHOLE DETECTED" : "NO POTHOLE DETECTED"}
                  </p>

                  {detection.detection && (
                    <p className="sv-detect-confidence-inline">
                      Confidence: {Number(detection.detection.confidence || 0).toFixed(3)}
                    </p>
                  )}
                </div>

                {detection.detection && (
                  <div className="sv-detect-metrics">
                    <p>
                      <strong>Severity:</strong> {formatSeverity(detection.detection.severity)}
                    </p>
                  </div>
                )}

                {imageSrc ? (
                  <div className="sv-detect-image-wrap">
                    <img src={imageSrc} alt="Street View pothole detection" />
                  </div>
                ) : (
                  <p className="sv-detect-status">No detection preview image returned.</p>
                )}
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  )
}
