# ai/__init__.py (stub for future YOLO integration)
