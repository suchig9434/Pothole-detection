import torch
import cv2
import numpy as np
from torchvision import models, transforms

# Load pretrained segmentation model
road_model = models.segmentation.deeplabv3_mobilenet_v3_large(pretrained=True)
road_model.eval()

transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((640,640)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485,0.456,0.406],
        std=[0.229,0.224,0.225]
    )
])

def get_road_mask(image):

    input_tensor = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = road_model(input_tensor)["out"][0]

    prediction = output.argmax(0).cpu().numpy()

    road_mask = prediction == 0

    road_mask = road_mask.astype(np.uint8)

    road_mask = cv2.resize(
        road_mask,
        (image.shape[1], image.shape[0]),
        interpolation=cv2.INTER_NEAREST
    )

    return road_mask