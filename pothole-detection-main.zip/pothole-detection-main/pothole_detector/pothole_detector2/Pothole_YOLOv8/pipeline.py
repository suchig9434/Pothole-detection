import cv2
import numpy as np
from ultralytics import YOLO

from road_segmentation import get_road_mask


_MODEL = YOLO("models/best.pt")


def _severity_from_ratio(area_ratio: float) -> str:
    if area_ratio < 0.005:
        return "Small"
    if area_ratio < 0.02:
        return "Medium"
    return "Dangerous"


def detect_potholes(image_path: str) -> dict:
    """
    Detect potholes on-road in an image.

    Returns:
    {
      "has_pothole": bool,
      "count": int,
      "detections": [
        {
          "bbox": [x1, y1, x2, y2],
          "area_ratio": float,
          "severity": "Small|Medium|Dangerous"
        }
      ]
    }
    """
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(f"Unable to read image: {image_path}")

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    road_mask = get_road_mask(image_rgb)

    results = _MODEL(image)
    boxes = results[0].boxes.xyxy.cpu().numpy() if results and results[0].boxes is not None else []

    road_area = max(1, int(np.sum(road_mask)))
    detections = []

    for box in boxes:
        x1, y1, x2, y2 = map(int, box)

        cx = int((x1 + x2) / 2)
        cy = int((y1 + y2) / 2)

        if cy < 0 or cy >= road_mask.shape[0] or cx < 0 or cx >= road_mask.shape[1]:
            continue

        if not road_mask[cy, cx]:
            continue

        pothole_area = max(0, (x2 - x1) * (y2 - y1))
        area_ratio = float(pothole_area) / float(road_area)
        severity = _severity_from_ratio(area_ratio)

        detections.append(
            {
                "bbox": [x1, y1, x2, y2],
                "area_ratio": area_ratio,
                "severity": severity,
            }
        )

    return {
        "has_pothole": len(detections) > 0,
        "count": len(detections),
        "detections": detections,
    }


if __name__ == "__main__":
    output = detect_potholes("images/test22.png")
    print(f"Detected potholes: {output['count']}")